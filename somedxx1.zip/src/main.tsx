import { createRoot } from 'react-dom/client';
import { APIProvider } from '@vis.gl/react-google-maps';
import App from './App.tsx';
import './index.css';

const googleMapsApiKey =
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_GOOGLE_MAPS_API_KEY) ||
  'AIzaSyDoekxnWyaYO0OgRyjpyRZMc_D_fP4ABug';

createRoot(document.getElementById('root')!).render(
  <APIProvider apiKey={googleMapsApiKey} libraries={['places', 'routes', 'geometry', 'marker']}>
    <App />
  </APIProvider>
);

// Register Service Worker for PWA & Android Native WebAPK installation
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  });
}
