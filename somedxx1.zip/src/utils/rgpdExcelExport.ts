import * as XLSX from 'xlsx';

export interface ExportMetadata {
  exportedAt: string;
  platform: string;
  legalNotice: string;
}

/**
 * Exporte les données personnelles d'un passager sous forme de classeur Excel (.xlsx) conforme RGPD.
 */
export function exportPassengerRGPDToExcel(passenger: any): void {
  const wb = XLSX.utils.book_new();

  // 1. Feuille : Profil et Informations Personnelles
  const profileRows = [
    { Propriété: 'Identifiant Unique Passager', Valeur: passenger.id || 'N/A' },
    { Propriété: 'Nom complet', Valeur: passenger.name || 'N/A' },
    { Propriété: 'Numéro de téléphone', Valeur: passenger.phone || 'N/A' },
    { Propriété: 'Adresse Email', Valeur: passenger.email || 'contact@somed.biz' },
    { Propriété: 'Note Passager', Valeur: `${passenger.rating || 5.0} / 5` },
    { Propriété: 'Nombre total de courses', Valeur: passenger.tripsCount || 0 },
    { Propriété: 'Solde du portefeuille (EUR)', Valeur: `${(passenger.walletBalance || 0).toFixed(2)} €` },
    { Propriété: 'Mode de paiement par défaut', Valeur: passenger.defaultPayment || 'CARTE' },
    { Propriété: 'Membre depuis', Valeur: String(passenger.memberSince || '2026') },
    { Propriété: 'Date de l’export RGPD', Valeur: new Date().toLocaleString('fr-FR') },
    { Propriété: 'Horodatage ISO', Valeur: new Date().toISOString() },
    { Propriété: 'Plateforme émettrice', Valeur: 'SOMED Mobility Platform' },
  ];
  const profileSheet = XLSX.utils.json_to_sheet(profileRows);
  // Largeur des colonnes pour un rendu propre dans Excel
  profileSheet['!cols'] = [{ wch: 35 }, { wch: 55 }];
  XLSX.utils.book_append_sheet(wb, profileSheet, 'Profil Passager');

  // 2. Feuille : Adresses et Lieux Favoris
  const addresses = passenger.savedAddresses || [];
  const locations = passenger.savedLocations || [];
  const combinedLocations = addresses.length > 0 
    ? addresses.map((addr: any, idx: number) => ({
        'N°': idx + 1,
        'Libellé': addr.label || 'Favori',
        'Adresse': addr.address || '',
        'Latitude': addr.lat || '',
        'Longitude': addr.lng || '',
      }))
    : locations.map((loc: any, idx: number) => ({
        'N°': idx + 1,
        'Libellé': loc.title || 'Favori',
        'Adresse': loc.address || '',
        'Latitude': loc.lat || '',
        'Longitude': loc.lng || '',
      }));

  const locationRows = combinedLocations.length > 0 
    ? combinedLocations 
    : [{ 'N°': 1, 'Libellé': 'Aucune adresse enregistrée', 'Adresse': '-', 'Latitude': '-', 'Longitude': '-' }];
  const locationSheet = XLSX.utils.json_to_sheet(locationRows);
  locationSheet['!cols'] = [{ wch: 6 }, { wch: 20 }, { wch: 50 }, { wch: 15 }, { wch: 15 }];
  XLSX.utils.book_append_sheet(wb, locationSheet, 'Lieux Favoris');

  // 3. Feuille : Moyens de paiement enregistrés (Tokenisés / Données masquées)
  const cards = passenger.savedCards || [];
  const cardRows = cards.length > 0 
    ? cards.map((card: any, idx: number) => ({
        'N°': idx + 1,
        'Réseau': card.brand || 'CB',
        'Numéro masqué': `•••• •••• •••• ${card.last4 || '0000'}`,
        'Expiration': `${card.expMonth || '12'}/${card.expYear || '2030'}`,
        'Passerelle sécurisée': card.gateway || 'Stripe PCI-DSS Level 1',
        'Par défaut': card.isDefault ? 'Oui' : 'Non',
      }))
    : [{ 'N°': 1, 'Réseau': 'Aucune carte bancaire', 'Numéro masqué': '-', 'Expiration': '-', 'Passerelle sécurisée': '-', 'Par défaut': '-' }];
  const cardSheet = XLSX.utils.json_to_sheet(cardRows);
  cardSheet['!cols'] = [{ wch: 6 }, { wch: 15 }, { wch: 25 }, { wch: 15 }, { wch: 25 }, { wch: 12 }];
  XLSX.utils.book_append_sheet(wb, cardSheet, 'Moyens de Paiement');

  // 4. Feuille : Historique & Transactions Portefeuille
  const transactions = passenger.walletTransactions || [];
  const txRows = transactions.length > 0 
    ? transactions.map((tx: any, idx: number) => ({
        'N°': idx + 1,
        'Référence': tx.id || `TX-${idx + 1}`,
        'Type d’opération': tx.type || 'Paiement',
        'Date': tx.date || '-',
        'Heure': tx.time || '-',
        'Description': tx.description || '-',
        'Montant (€)': tx.amount !== undefined ? Number(tx.amount).toFixed(2) : '0.00',
      }))
    : [{ 'N°': 1, 'Référence': 'Aucune transaction', 'Type d’opération': '-', 'Date': '-', 'Heure': '-', 'Description': '-', 'Montant (€)': '-' }];
  const txSheet = XLSX.utils.json_to_sheet(txRows);
  txSheet['!cols'] = [{ wch: 6 }, { wch: 20 }, { wch: 20 }, { wch: 25 }, { wch: 12 }, { wch: 45 }, { wch: 15 }];
  XLSX.utils.book_append_sheet(wb, txSheet, 'Transactions');

  // 5. Feuille : Cadre de Conformité RGPD (Articles 15, 17, 20)
  const rgpdLegal = [
    { 'Article RGPD': 'Article 15 - Droit d’accès', 'Portée légale': 'Droit de la personne concernée d’obtenir confirmation que des données la concernant sont traitées et d’en recevoir une copie.' },
    { 'Article RGPD': 'Article 17 - Droit à l’effacement', 'Portée légale': 'Droit à l’oubli et suppression définitive des données personnelles sur simple demande via l’application.' },
    { 'Article RGPD': 'Article 20 - Portabilité des données', 'Portée légale': 'Transmission des données sous un format structuré, couramment utilisé et lisible par machine (Microsoft Excel .xlsx).' },
    { 'Article RGPD': 'Responsable du traitement', 'Portée légale': 'SOMED Mobility SAS - 75008 Paris - France' },
    { 'Article RGPD': 'Délégué à la protection (DPO)', 'Portée légale': 'dpo@somed.biz' },
    { 'Article RGPD': 'Certificat d’exportation', 'Portée légale': `Généré à la demande de l’utilisateur le ${new Date().toLocaleString('fr-FR')}` },
  ];
  const legalSheet = XLSX.utils.json_to_sheet(rgpdLegal);
  legalSheet['!cols'] = [{ wch: 35 }, { wch: 80 }];
  XLSX.utils.book_append_sheet(wb, legalSheet, 'Conformité RGPD');

  // Téléchargement du fichier Excel
  const safeName = (passenger.name || 'passager').replace(/[^a-zA-Z0-9_-]/g, '_');
  const filename = `SOMED_Export_RGPD_Passager_${safeName}_${new Date().toISOString().slice(0, 10)}.xlsx`;
  XLSX.writeFile(wb, filename);
}

/**
 * Exporte les données professionnelles d'un chauffeur sous forme de classeur Excel (.xlsx) conforme RGPD.
 */
export function exportDriverRGPDToExcel(driver: any): void {
  const wb = XLSX.utils.book_new();

  // 1. Feuille : Profil Chauffeur Partenaire
  const profileRows = [
    { Propriété: 'Identifiant Unique Chauffeur', Valeur: driver.id || 'N/A' },
    { Propriété: 'Nom et Prénom', Valeur: driver.name || 'N/A' },
    { Propriété: 'Numéro de téléphone', Valeur: driver.phone || 'N/A' },
    { Propriété: 'Adresse Email', Valeur: driver.email || 'N/A' },
    { Propriété: 'Note de service', Valeur: `${driver.rating || 5.0} / 5` },
    { Propriété: 'Courses totales réalisées', Valeur: driver.totalRides || 0 },
    { Propriété: 'Solde portefeuille Chauffeur (EUR)', Valeur: `${(driver.driverWalletBalance || 0).toFixed(2)} €` },
    { Propriété: 'Gains du jour (EUR)', Valeur: `${(driver.todayEarnings || 0).toFixed(2)} €` },
    { Propriété: 'Gains de la semaine (EUR)', Valeur: `${(driver.weeklyEarnings || 0).toFixed(2)} €` },
    { Propriété: 'Taux d’acceptation', Valeur: `${driver.acceptanceRate || 95} %` },
    { Propriété: 'Modèle du véhicule', Valeur: driver.vehicle?.model || 'N/A' },
    { Propriété: 'Immatriculation', Valeur: driver.vehicle?.plate || 'N/A' },
    { Propriété: 'Couleur du véhicule', Valeur: driver.vehicle?.color || 'N/A' },
    { Propriété: 'Catégorie VTC', Valeur: driver.vehicle?.category || 'CONFORT' },
    { Propriété: 'GPS Préféré', Valeur: driver.preferredGps || 'Waze' },
    { Propriété: 'Statut en ligne actuel', Valeur: driver.isOnline ? 'En ligne' : 'Hors ligne' },
    { Propriété: 'Date de l’export RGPD', Valeur: new Date().toLocaleString('fr-FR') },
    { Propriété: 'Plateforme émettrice', Valeur: 'SOMED Mobility Partner Network' },
  ];
  const profileSheet = XLSX.utils.json_to_sheet(profileRows);
  profileSheet['!cols'] = [{ wch: 35 }, { wch: 55 }];
  XLSX.utils.book_append_sheet(wb, profileSheet, 'Profil Chauffeur');

  // 2. Feuille : Documents Réglementaires & Conformité VTC / Taxi
  const docs = driver.documentsList || [];
  const docRows = docs.length > 0 
    ? docs.map((doc: any, idx: number) => ({
        'N°': idx + 1,
        'Intitulé du document': doc.title || 'Document',
        'Description / Portée': doc.subtitle || '-',
        'Statut administratif': doc.status === 'VALID' ? 'Validé' : doc.status === 'PENDING' ? 'En cours de revue' : 'Requis / Non conforme',
        'Numéro de référence': doc.referenceNumber || 'N/A',
        'Date d’expiration': doc.expiryDate || 'N/A',
        'Dernière mise à jour': doc.lastUpdated || 'N/A',
        'Obligation légale': doc.isMandatory ? 'Obligatoire' : 'Facultatif',
        'Format de pièce': doc.requiredSides === 'RECTO_VERSO' ? 'Recto & Verso' : 'Document complet',
      }))
    : [{ 'N°': 1, 'Intitulé du document': 'Aucun document enregistré', 'Description / Portée': '-', 'Statut administratif': '-', 'Numéro de référence': '-', 'Date d’expiration': '-', 'Dernière mise à jour': '-', 'Obligation légale': '-', 'Format de pièce': '-' }];
  const docSheet = XLSX.utils.json_to_sheet(docRows);
  docSheet['!cols'] = [{ wch: 6 }, { wch: 32 }, { wch: 45 }, { wch: 22 }, { wch: 22 }, { wch: 18 }, { wch: 18 }, { wch: 18 }, { wch: 18 }];
  XLSX.utils.book_append_sheet(wb, docSheet, 'Documents Réglementaires');

  // 3. Feuille : Coordonnées Bancaires (Virements Chauffeur)
  const bankInfo = driver.bankInfo || {};
  const bankRows = [
    { Propriété: 'Titulaire du compte bancaire', Valeur: bankInfo.accountHolder || driver.name },
    { Propriété: 'Identifiant IBAN', Valeur: bankInfo.iban || 'FR76 •••• •••• •••• •••• •••• •••' },
    { Propriété: 'Code BIC / SWIFT', Valeur: bankInfo.bic || '••••••••' },
    { Propriété: 'Établissement bancaire', Valeur: bankInfo.bankName || 'Banque partenaire' },
  ];
  const bankSheet = XLSX.utils.json_to_sheet(bankRows);
  bankSheet['!cols'] = [{ wch: 35 }, { wch: 55 }];
  XLSX.utils.book_append_sheet(wb, bankSheet, 'Données Bancaires');

  // 4. Feuille : Transactions & Commissions
  const transactions = driver.driverTransactions || [];
  const txRows = transactions.length > 0 
    ? transactions.map((tx: any, idx: number) => ({
        'N°': idx + 1,
        'Référence': tx.id || `TX-${idx + 1}`,
        'Type d’opération': tx.type || '-',
        'Date': tx.date || '-',
        'Heure': tx.time || '-',
        'Intitulé': tx.title || '-',
        'Description détaillée': tx.description || '-',
        'Montant (€)': tx.amount !== undefined ? Number(tx.amount).toFixed(2) : '0.00',
        'Statut': tx.status || 'Completed',
        'Code Course associé': tx.tripCode || '-',
        'Origine': tx.origin || '-',
        'Destination': tx.destination || '-',
      }))
    : [{ 'N°': 1, 'Référence': 'Aucune transaction', 'Type d’opération': '-', 'Date': '-', 'Heure': '-', 'Intitulé': '-', 'Description détaillée': '-', 'Montant (€)': '-', 'Statut': '-', 'Code Course associé': '-', 'Origine': '-', 'Destination': '-' }];
  const txSheet = XLSX.utils.json_to_sheet(txRows);
  txSheet['!cols'] = [{ wch: 6 }, { wch: 18 }, { wch: 22 }, { wch: 25 }, { wch: 12 }, { wch: 28 }, { wch: 45 }, { wch: 14 }, { wch: 14 }, { wch: 18 }, { wch: 35 }, { wch: 35 }];
  XLSX.utils.book_append_sheet(wb, txSheet, 'Transactions & Gains');

  // 5. Feuille : Cadre de Conformité RGPD & Obligations Légales de Conservation
  const rgpdLegal = [
    { 'Article / Règlement': 'Article 15 RGPD - Droit d’accès', 'Application': 'Accès à l’ensemble des données professionnelles, financières et techniques traitées par la plateforme.' },
    { 'Article / Règlement': 'Article 17 RGPD - Droit à l’effacement', 'Application': 'Suppression des données personnelles et de profil sous réserve de la conservation légale obligatoire des factures (Livre des procédures fiscales / Code de commerce).' },
    { 'Article / Règlement': 'Article 20 RGPD - Portabilité des données', 'Application': 'Export complet sous format ouvert Microsoft Excel (.xlsx).' },
    { 'Article / Règlement': 'Responsable du traitement', 'Application': 'SOMED Mobility SAS - Service Conformité et DPO' },
    { 'Article / Règlement': 'Délégué à la protection des données', 'Application': 'dpo@somed.biz' },
    { 'Article / Règlement': 'Horodatage certifié de l’export', 'Application': `${new Date().toLocaleString('fr-FR')} (${new Date().toISOString()})` },
  ];
  const legalSheet = XLSX.utils.json_to_sheet(rgpdLegal);
  legalSheet['!cols'] = [{ wch: 35 }, { wch: 80 }];
  XLSX.utils.book_append_sheet(wb, legalSheet, 'Conformité RGPD');

  // Téléchargement du fichier Excel
  const safeName = (driver.name || 'chauffeur').replace(/[^a-zA-Z0-9_-]/g, '_');
  const filename = `SOMED_Export_RGPD_Chauffeur_${safeName}_${new Date().toISOString().slice(0, 10)}.xlsx`;
  XLSX.writeFile(wb, filename);
}
