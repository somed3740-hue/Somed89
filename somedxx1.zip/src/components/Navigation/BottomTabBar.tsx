import React from 'react';
import { Bike, Clock, User } from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { useTranslation } from '../../utils/i18n';

// Front-facing taxi icon matching the user's second reference image (IMG_20261014_043139.jpg)
const TaxiFrontIcon: React.FC<{ className?: string }> = ({ className = 'w-4.5 h-4.5' }) => (
  <svg 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    className={className}
    aria-hidden="true"
  >
    {/* Taxi roof sign */}
    <rect x="9.5" y="2" width="5" height="2.2" rx="0.8" />
    
    {/* Car body with windshield & headlights cut out */}
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M7.5 4.8C6.6 4.8 5.8 5.3 5.4 6.1L3.3 10.7C3 11.4 2.8 12 2.8 12.8V18.5C2.8 19.3 3.5 20 4.3 20H5V21.5C5 22.1 5.4 22.5 6 22.5H8C8.6 22.5 9 22.1 9 21.5V20H15V21.5C15 22.1 15.4 22.5 16 22.5H18C18.6 22.5 19 22.1 19 21.5V20H19.7C20.5 20 21.2 19.3 21.2 18.5V12.8C21.2 12 21 11.4 20.7 10.7L18.6 6.1C18.2 5.3 17.4 4.8 16.5 4.8H7.5ZM8.2 6.8H15.8C16.3 6.8 16.7 7.1 16.9 7.6L18.2 11C18.4 11.5 18 12 17.5 12H6.5C6 12 5.6 11.5 5.8 11L7.1 7.6C7.3 7.1 7.7 6.8 8.2 6.8ZM6.8 16C6.8 16.7 6.2 17.2 5.5 17.2C4.8 17.2 4.2 16.7 4.2 16C4.2 15.3 4.8 14.8 5.5 14.8C6.2 14.8 6.8 15.3 6.8 16ZM19.8 16C19.8 16.7 19.2 17.2 18.5 17.2C17.8 17.2 17.2 16.7 17.2 16C17.2 15.3 17.8 14.8 18.5 14.8C19.2 14.8 19.8 15.3 19.8 16Z"
    />
  </svg>
);

interface BottomTabBarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
}

export const BottomTabBar: React.FC<BottomTabBarProps> = ({
  currentTab,
  onSelectTab,
}) => {
  const isLight = vtcStore.isLightMode();
  const { t } = useTranslation();

  const tabs = [
    { id: 'taxi', label: t('tabTaxi'), icon: TaxiFrontIcon },
    { id: 'delivery', label: t('tabDelivery'), icon: Bike },
    { id: 'activity', label: t('tabActivity'), icon: Clock },
    { id: 'profile', label: t('tabProfile'), icon: User },
  ];

  return (
    <nav className={`h-16 border-t px-6 flex items-center justify-around flex-shrink-0 z-30 select-none shadow-2xl transition-colors ${
      isLight ? 'bg-white border-slate-200 text-slate-700' : 'bg-black border-neutral-900 text-neutral-400'
    }`}>
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = currentTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onSelectTab(tab.id)}
            className="flex flex-col items-center justify-center gap-1 py-1 px-3 relative transition active:scale-95 group"
          >
            {isActive ? (
              <div className="w-12 h-7 rounded-full bg-yellow-400 flex items-center justify-center transition-all shadow-md shadow-yellow-400/20">
                <Icon className="w-4.5 h-4.5 text-black stroke-[2.5]" />
              </div>
            ) : (
              <div className={`w-12 h-7 flex items-center justify-center transition ${
                isLight ? 'text-slate-500 group-hover:text-black' : 'text-neutral-400 group-hover:text-white'
              }`}>
                <Icon className="w-5 h-5 stroke-[1.8]" />
              </div>
            )}
            <span
              className={`text-[10px] font-semibold transition ${
                isActive 
                  ? 'text-yellow-500 font-bold' 
                  : isLight ? 'text-slate-500 group-hover:text-black' : 'text-neutral-400 group-hover:text-neutral-200'
              }`}
            >
              {tab.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
