import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  ArrowLeft, 
  Crosshair, 
  MapPin, 
  Loader2, 
  Check, 
  Navigation,
  Keyboard,
  Edit3,
  Compass
} from 'lucide-react';
import { LocationPoint } from '../../types/vtc';
import { VtcMap } from '../Map/VtcMap';
import { reverseGeocodeAddress } from '../../utils/geo';
import { soundEffects } from '../../utils/audio';
import { vtcStore } from '../../services/vtcStore';
import { LocationDisclosureModal } from '../Modals/LocationDisclosureModal';

export interface SetOnMapViewProps {
  mode: 'PICKUP' | 'DESTINATION' | 'STOP';
  initialLocation?: LocationPoint | null;
  onConfirm: (location: LocationPoint) => void;
  onCancel: () => void;
  onSwitchToManual?: () => void;
}

/**
 * SetOnMapView:
 * Full-screen map location picker matching exact ride-hailing UX (as on Screenshot_20261005-035608.jpg):
 * - Interactive dark map with centered pin indicator that reacts to dragging
 * - Top-left back button
 * - Top-center quick switch to manual address typing
 * - Top-right GPS locate/recenter button with real device geolocation
 * - Real-time reverse geocoding with debounce
 * - Bottom sheet drawer with destination/pickup dot, live address, and bright yellow Confirm button
 */
export const SetOnMapView: React.FC<SetOnMapViewProps> = ({
  mode,
  initialLocation,
  onConfirm,
  onCancel,
  onSwitchToManual,
}) => {
  // Center coordinates: fallback to Marrakech or Paris preset
  const [centerCoord, setCenterCoord] = useState<{ lat: number; lng: number }>(() => {
    if (initialLocation && initialLocation.lat && initialLocation.lng) {
      return { lat: initialLocation.lat, lng: initialLocation.lng };
    }
    // Default to initial location in Marrakech or Paris
    return { lat: 31.6295, lng: -7.9811 };
  });

  const [currentPoint, setCurrentPoint] = useState<LocationPoint>(() => {
    if (initialLocation && initialLocation.address) {
      return initialLocation;
    }
    return {
      lat: 31.6295,
      lng: -7.9811,
      name: 'Point sur la carte',
      address: '18 Avenue Mohammed VI, Marrakech',
    };
  });

  const [isGeocoding, setIsGeocoding] = useState<boolean>(false);
  const [isLocatingGps, setIsLocatingGps] = useState<boolean>(false);
  const [isMoving, setIsMoving] = useState<boolean>(false);
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);
  const moveTimerRef = useRef<NodeJS.Timeout | null>(null);

  const isDestination = mode === 'DESTINATION';
  const isPickup = mode === 'PICKUP';

  // Label text matching ride-hailing reference image
  const typeLabel = isDestination 
    ? 'Destination' 
    : isPickup 
    ? 'Point de départ' 
    : 'Étape intermédiaire';

  const confirmBtnText = isDestination
    ? 'Confirm destination'
    : isPickup
    ? 'Confirm pickup'
    : 'Confirmer l’étape';

  const pinColor = isDestination ? '#EF4444' : isPickup ? '#10B981' : '#F59E0B';

  // Reverse geocode when center changes (debounced)
  const triggerReverseGeocode = useCallback((lat: number, lng: number) => {
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }

    setIsGeocoding(true);
    debounceTimerRef.current = setTimeout(async () => {
      try {
        const point = await reverseGeocodeAddress(lat, lng);
        setCurrentPoint(point);
      } catch {
        setCurrentPoint({
          lat,
          lng,
          name: 'Point sur la carte',
          address: `Position (${lat.toFixed(4)}, ${lng.toFixed(4)})`,
        });
      } finally {
        setIsGeocoding(false);
      }
    }, 450);
  }, []);

  // Center coordinate change handler (called on map pan, drag, or click)
  const handlePositionChange = useCallback((lat: number, lng: number) => {
    setCenterCoord({ lat, lng });
    setIsMoving(true);
    if (moveTimerRef.current) clearTimeout(moveTimerRef.current);
    moveTimerRef.current = setTimeout(() => {
      setIsMoving(false);
    }, 250);
    triggerReverseGeocode(lat, lng);
  }, [triggerReverseGeocode]);

  const [isDisclosureOpen, setIsDisclosureOpen] = useState(false);

  // Execute GPS locate once user continues from disclosure
  const executeGpsLocate = () => {
    setIsLocatingGps(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          handlePositionChange(lat, lng);
          setIsLocatingGps(false);
        },
        () => {
          // Fallback to default position
          handlePositionChange(31.6295, -7.9811);
          setIsLocatingGps(false);
        },
        { enableHighAccuracy: true, timeout: 6000 }
      );
    } else {
      setIsLocatingGps(false);
    }
  };

  // Recenter map to user's real browser GPS position
  const handleRecenterGps = () => {
    soundEffects.playClick();
    try {
      if (localStorage.getItem('somed_location_permission') !== 'granted') {
        setIsDisclosureOpen(true);
        return;
      }
    } catch {}
    executeGpsLocate();
  };

  const handleConfirmLocation = () => {
    soundEffects.playSuccessSound();
    onConfirm(currentPoint);
  };

  return (
    <div className="fixed inset-0 z-[1200] flex flex-col bg-slate-950 select-none animate-in fade-in duration-200">
      {/* 1. Full-screen Interactive Map Container */}
      <div className="relative flex-1 w-full h-full overflow-hidden">
        <VtcMap
          center={[centerCoord.lat, centerCoord.lng]}
          zoom={16}
          interactive={true}
          theme="dark"
          className="h-full w-full"
          onMapClick={(lat, lng) => {
            handlePositionChange(lat, lng);
          }}
          onCenterChange={(lat, lng) => {
            handlePositionChange(lat, lng);
          }}
        />

        {/* 2. Top Bar (Back button, Title / Mode Switcher, Recenter GPS) */}
        <div className="absolute top-4 inset-x-4 z-30 flex items-center justify-between pointer-events-none">
          {/* Top-Left Back Button */}
          <button
            type="button"
            onClick={onCancel}
            title="Retour à la vue précédente"
            className="w-11 h-11 rounded-full bg-slate-950/85 hover:bg-slate-900 text-white flex items-center justify-center border border-slate-700/80 shadow-2xl backdrop-blur-md active:scale-95 transition pointer-events-auto cursor-pointer group"
          >
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-0.5 transition-transform" />
          </button>

          {/* Top-Center Switch to Manual Address Button */}
          {onSwitchToManual && (
            <button
              type="button"
              onClick={onSwitchToManual}
              title="Saisie manuelle"
              aria-label="Saisie manuelle"
              className="w-11 h-11 rounded-full bg-slate-950/85 hover:bg-slate-900 text-slate-200 hover:text-white border border-slate-700/80 shadow-xl backdrop-blur-md flex items-center justify-center pointer-events-auto cursor-pointer transition active:scale-95"
            >
              <Keyboard className="w-5 h-5 text-yellow-400" />
            </button>
          )}

          {/* Top-Right Recenter GPS Button */}
          <button
            type="button"
            onClick={handleRecenterGps}
            title="Centrer sur ma position GPS"
            className="w-11 h-11 rounded-full bg-slate-950/85 hover:bg-slate-900 text-white flex items-center justify-center border border-slate-700/80 shadow-2xl backdrop-blur-md active:scale-95 transition hover:text-yellow-400 pointer-events-auto cursor-pointer group"
          >
            {isLocatingGps ? (
              <Loader2 className="w-5 h-5 text-yellow-400 animate-spin" />
            ) : (
              <Crosshair className="w-5 h-5 group-hover:rotate-45 transition-transform" />
            )}
          </button>
        </div>

        {/* 3. Centered Pin Icon with Ground Target Point and Dynamic Lift Animation */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-full pointer-events-none z-20 flex flex-col items-center">
          {/* Main Pin Icon: lifts up slightly when moving/panning */}
          <div 
            className={`relative -mb-1 transition-transform duration-200 ease-out origin-bottom ${
              isMoving ? '-translate-y-3.5 scale-110 drop-shadow-[0_18px_24px_rgba(0,0,0,0.8)]' : 'translate-y-0 scale-100 drop-shadow-[0_8px_16px_rgba(0,0,0,0.7)]'
            }`}
          >
            <svg
              width="42"
              height="52"
              viewBox="0 0 38 48"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Outer Glow Ring on movement */}
              {isMoving && (
                <circle cx="19" cy="19" r="18" fill={pinColor} opacity="0.25" />
              )}
              {/* Teardrop Pin Body */}
              <path
                d="M 19 0 C 8.5 0 0 8.5 0 19 C 0 31 16 45.5 18.2 47.4 C 18.7 47.8 19.3 47.8 19.8 47.4 C 22 45.5 38 31 38 19 C 38 8.5 29.5 0 19 0 Z"
                fill={pinColor}
                stroke="#FFFFFF"
                strokeWidth="2"
              />
              {/* Inner Center Dot */}
              <circle cx="19" cy="18" r="6.5" fill="#0F172A" />
              <circle cx="19" cy="18" r="3.5" fill="#FFFFFF" opacity="0.9" />
            </svg>
          </div>

          {/* Ground Contact Shadow Point: shrinks when pin lifts */}
          <div 
            className={`bg-black/75 rounded-full blur-[1px] transform scale-y-75 transition-all duration-200 ${
              isMoving ? 'w-2 h-1 opacity-40 mt-3' : 'w-4 h-1.5 opacity-90 mt-0.5'
            }`} 
          />
        </div>

        {/* Floating Instruction Banner */}
        <div className="absolute top-20 left-1/2 -translate-x-1/2 z-20 pointer-events-none">
          <div className="bg-slate-950/85 backdrop-blur-md text-slate-200 text-[11px] font-semibold px-4 py-1.5 rounded-full border border-slate-700/60 shadow-xl flex items-center gap-2">
            <span className={`w-2 h-2 rounded-full ${isMoving ? 'bg-yellow-400 animate-ping' : 'bg-emerald-400'}`} />
            <span>Déplacez la carte ou cliquez pour positionner le repère</span>
          </div>
        </div>
      </div>

      {/* 4. Bottom Sheet Drawer (Matches exact layout from ride-hailing reference image) */}
      <div className="relative z-30 bg-neutral-950/95 border-t border-slate-800/80 rounded-t-[32px] p-5 pb-8 shadow-2xl backdrop-blur-xl flex flex-col space-y-4">
        {/* Drag handle line */}
        <div className="w-12 h-1 bg-neutral-700 rounded-full mx-auto" />

        {/* Destination / Pickup label + Address text */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <p className="text-xs text-neutral-400 font-semibold uppercase tracking-wider">
              {typeLabel}
            </p>
            {onSwitchToManual && (
              <button
                type="button"
                onClick={onSwitchToManual}
                className="text-xs text-yellow-400 hover:text-yellow-300 font-semibold flex items-center gap-1 transition"
              >
                <Edit3 className="w-3 h-3" />
                <span>Modifier au clavier</span>
              </button>
            )}
          </div>

          <div className="flex items-start gap-3 min-w-0">
            {/* Color dot matching Screenshot */}
            <span
              className="w-3.5 h-3.5 rounded-full flex-shrink-0 mt-1 shadow-sm"
              style={{ backgroundColor: pinColor }}
            />

            {/* Address text */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <p className="text-base sm:text-lg font-bold text-white truncate tracking-tight">
                  {currentPoint.name || currentPoint.address}
                </p>
                {isGeocoding && (
                  <Loader2 className="w-4 h-4 text-yellow-400 animate-spin flex-shrink-0" />
                )}
              </div>
              <p className="text-xs text-slate-400 truncate mt-0.5">
                {currentPoint.address}
              </p>
            </div>
          </div>
        </div>

        {/* Big Bright Yellow Confirm Button (exact match from reference image) */}
        <button
          type="button"
          onClick={handleConfirmLocation}
          className="w-full py-4 rounded-2xl bg-yellow-400 hover:bg-yellow-300 active:scale-[0.99] text-black font-extrabold text-base sm:text-lg shadow-xl shadow-yellow-400/20 transition duration-150 flex items-center justify-center gap-2 cursor-pointer"
        >
          <Check className="w-5 h-5 stroke-[2.5]" />
          <span>{confirmBtnText}</span>
        </button>
      </div>

      {/* Location Disclosure Modal (Image 2) */}
      <LocationDisclosureModal
        isOpen={isDisclosureOpen}
        onClose={() => setIsDisclosureOpen(false)}
        onContinue={() => {
          try {
            localStorage.setItem('somed_location_permission', 'granted');
          } catch {}
          setIsDisclosureOpen(false);
          executeGpsLocate();
        }}
      />
    </div>
  );
};
