import React from 'react';
import { DriverPictogramConfig, VehicleColorPreset, VehiclePictogramType } from '../../types/vtc';

export interface TopDownCarMarkerProps {
  heading?: number; // 0 to 360 degrees
  driverName?: string;
  isLive?: boolean;
  size?: number; // base width in pixels (default: 30)
  config?: Partial<DriverPictogramConfig>;
  speedKmh?: number;
  onClick?: () => void;
  className?: string;
  interactive?: boolean;
}

export const DEFAULT_PICTOGRAM_CONFIG: DriverPictogramConfig = {
  vehicleType: 'SEDAN',
  color: 'white',
  headlightsEnabled: true,
  headlightsColor: 'yellow',
  haloPulse: 'blue',
  size: 30,
  showDriverTag: true,
  showSpeedIndicator: false,
};

// Color palettes for vehicle chassis
export const COLOR_PALETTES: Record<string, { body: string; border: string; roof: string; accent: string; name: string }> = {
  white: {
    name: 'Blanc Nacré',
    body: '#FFFFFF',
    border: '#CBD5E1',
    roof: '#F8FAFC',
    accent: '#E2E8F0',
  },
  black: {
    name: 'Noir Obsidienne',
    body: '#0F172A',
    border: '#334155',
    roof: '#1E293B',
    accent: '#475569',
  },
  gold: {
    name: 'Or SOMED Prestige',
    body: '#D97706',
    border: '#FBBF24',
    roof: '#B45309',
    accent: '#FDE68A',
  },
  silver: {
    name: 'Gris Métallisé',
    body: '#64748B',
    border: '#94A3B8',
    roof: '#475569',
    accent: '#E2E8F0',
  },
  navy: {
    name: 'Bleu Nuit',
    body: '#1E3A8A',
    border: '#3B82F6',
    roof: '#172554',
    accent: '#60A5FA',
  },
  red: {
    name: 'Rouge Rubis',
    body: '#DC2626',
    border: '#EF4444',
    roof: '#991B1B',
    accent: '#FCA5A5',
  },
  emerald: {
    name: 'Vert Émeraude',
    body: '#059669',
    border: '#10B981',
    roof: '#064E3B',
    accent: '#6EE7B7',
  },
};

export const HEADLIGHT_COLORS: Record<string, { light: string; beam: string; label: string }> = {
  yellow: {
    label: 'Jaune Ambre (Réf. Image)',
    light: '#FACC15',
    beam: 'rgba(250, 204, 21, 0.45)',
  },
  white: {
    label: 'Xénon Blanc LED',
    light: '#FFFFFF',
    beam: 'rgba(255, 255, 255, 0.55)',
  },
  blue: {
    label: 'Laser Bleu Ice',
    light: '#60A5FA',
    beam: 'rgba(96, 165, 250, 0.45)',
  },
};

/**
 * TopDownCarMarker:
 * Ultra-realistic, top-down GPS navigation pictogram for real-time moving driver
 * with customizable vehicle body (Sedan, Luxury Berline, SUV, Van, Sport, Moto),
 * paint colors (white, obsidian black, gold, silver, etc.),
 * dynamic road headlight beams, taillight glows, and heading rotation.
 */
export const TopDownCarMarker: React.FC<TopDownCarMarkerProps> = ({
  heading = 0,
  driverName,
  isLive = false,
  size: propSize,
  config,
  speedKmh,
  onClick,
  className = '',
  interactive = true,
}) => {
  const effectiveConfig: DriverPictogramConfig = {
    ...DEFAULT_PICTOGRAM_CONFIG,
    ...config,
    size: propSize || config?.size || DEFAULT_PICTOGRAM_CONFIG.size,
  };

  const palette = COLOR_PALETTES[effectiveConfig.color] || {
    name: 'Personnalisé',
    body: effectiveConfig.color,
    border: '#94A3B8',
    roof: effectiveConfig.color,
    accent: '#CBD5E1',
  };

  const headlight = HEADLIGHT_COLORS[effectiveConfig.headlightsColor || 'yellow'] || HEADLIGHT_COLORS.yellow;
  const size = effectiveConfig.size;
  const vehicleType = effectiveConfig.vehicleType || 'SEDAN';

  // Proportions based on vehicle type
  let width = size;
  let height = Math.round((size * 48) / 28);
  if (vehicleType === 'SUV') {
    width = Math.round(size * 1.08);
    height = Math.round((size * 50) / 28);
  } else if (vehicleType === 'BERLINE_LUXE') {
    height = Math.round((size * 52) / 28);
  } else if (vehicleType === 'VAN') {
    width = Math.round(size * 1.05);
    height = Math.round((size * 54) / 28);
  } else if (vehicleType === 'SPORT') {
    height = Math.round((size * 46) / 28);
  } else if (vehicleType === 'MOTO') {
    width = Math.round(size * 0.65);
    height = Math.round((size * 44) / 28);
  }

  // Halo colors
  const haloColorMap: Record<string, string> = {
    gold: 'bg-amber-500/25 ring-amber-400/40',
    blue: 'bg-blue-500/25 ring-blue-400/40',
    emerald: 'bg-emerald-500/25 ring-emerald-400/40',
    none: 'transparent ring-transparent',
  };

  return (
    <div
      onClick={onClick}
      className={`relative flex flex-col items-center justify-center select-none ${
        interactive ? 'cursor-pointer group' : ''
      } ${className}`}
      style={{
        width: `${width + 36}px`,
        height: `${height + 36}px`,
      }}
      title={driverName ? `Chauffeur: ${driverName} (Cliquer pour personnaliser)` : 'Véhicule en déplacement'}
    >
      {/* GPS Real-time Animated Radar Pulse Halo */}
      {isLive && effectiveConfig.haloPulse !== 'none' && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div
            className={`w-14 h-14 rounded-full animate-ping ${
              haloColorMap[effectiveConfig.haloPulse] || 'bg-blue-500/20'
            }`}
          />
          <div
            className={`absolute w-10 h-10 rounded-full ring-2 animate-pulse ${
              haloColorMap[effectiveConfig.haloPulse] || 'ring-blue-400/30'
            }`}
          />
        </div>
      )}

      {/* Rotating Chassis + Headlight Beams */}
      <div
        className="relative transition-transform duration-350 ease-out flex items-center justify-center"
        style={{
          transform: `rotate(${heading}deg)`,
          transformOrigin: 'center center',
          filter: 'drop-shadow(0 4px 8px rgba(0, 0, 0, 0.65))',
        }}
      >
        {/* Dynamic Headlight Light Beams projected forward on the road */}
        {effectiveConfig.headlightsEnabled && vehicleType !== 'MOTO' && (
          <div
            className="absolute -top-12 left-1/2 -translate-x-1/2 w-20 h-14 pointer-events-none opacity-80"
            style={{
              background: `radial-gradient(ellipse at 50% 100%, ${headlight.beam} 0%, rgba(255,255,255,0.08) 50%, transparent 80%)`,
              clipPath: 'polygon(35% 100%, 65% 100%, 100% 0%, 0% 0%)',
            }}
          />
        )}

        {/* Dynamic Single Motorcycle Headlight Beam */}
        {effectiveConfig.headlightsEnabled && vehicleType === 'MOTO' && (
          <div
            className="absolute -top-12 left-1/2 -translate-x-1/2 w-14 h-14 pointer-events-none opacity-85"
            style={{
              background: `radial-gradient(ellipse at 50% 100%, ${headlight.beam} 0%, rgba(255,255,255,0.05) 55%, transparent 80%)`,
              clipPath: 'polygon(40% 100%, 60% 100%, 90% 0%, 10% 0%)',
            }}
          />
        )}

        {/* SVG Vehicle Chassis based on model */}
        {renderVehicleSvg({
          type: vehicleType,
          width,
          height,
          palette,
          headlight,
          effectiveConfig,
        })}
      </div>

      {/* Floating Driver Tag & Speed Pill */}
      {effectiveConfig.showDriverTag && driverName && (
        <div
          className={`absolute -top-6 px-2 py-0.5 rounded-full text-[9px] font-bold whitespace-nowrap shadow-xl pointer-events-none transition-transform group-hover:scale-105 flex items-center gap-1 border ${
            isLive
              ? 'bg-slate-950/95 text-white border-blue-500/70 shadow-blue-500/20'
              : 'bg-slate-900/95 text-slate-200 border-slate-700/80'
          }`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span>{driverName}</span>
          {speedKmh !== undefined && speedKmh > 0 && (
            <span className="text-[8px] text-yellow-400 font-mono pl-0.5">· {speedKmh} km/h</span>
          )}
        </div>
      )}
    </div>
  );
};

interface RenderSvgProps {
  type: VehiclePictogramType;
  width: number;
  height: number;
  palette: { body: string; border: string; roof: string; accent: string };
  headlight: { light: string; beam: string };
  effectiveConfig: DriverPictogramConfig;
}

function renderVehicleSvg({ type, width, height, palette, headlight, effectiveConfig }: RenderSvgProps) {
  if (type === 'MOTO') {
    return (
      <svg
        width={width}
        height={height}
        viewBox="0 0 18 44"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="transition-transform duration-150"
      >
        {/* Wheels */}
        <rect x="7" y="1" width="4" height="9" rx="2" fill="#0F172A" stroke="#334155" strokeWidth="0.5" />
        <rect x="7" y="34" width="4" height="9" rx="2" fill="#0F172A" stroke="#334155" strokeWidth="0.5" />
        {/* Handlebars */}
        <line x1="2" y1="12" x2="16" y2="12" stroke="#475569" strokeWidth="1.8" strokeLinecap="round" />
        <circle cx="2" cy="12" r="1.2" fill="#0F172A" />
        <circle cx="16" cy="12" r="1.2" fill="#0F172A" />
        {/* Front Headlight */}
        <circle cx="9" cy="3" r="2" fill={effectiveConfig.headlightsEnabled ? headlight.light : '#94A3B8'} />
        {/* Body Tank */}
        <rect x="5.5" y="13" width="7" height="12" rx="3.5" fill={palette.body} stroke={palette.border} strokeWidth="0.8" />
        {/* Rider Helmet */}
        <circle cx="9" cy="22" r="3.8" fill="#1E293B" stroke="#CBD5E1" strokeWidth="0.6" />
        {/* Helmet Visor */}
        <path d="M 6.5 20 Q 9 18.5 11.5 20" stroke="#38BDF8" strokeWidth="1.2" strokeLinecap="round" fill="none" />
        {/* Seat & Rear */}
        <rect x="6.5" y="27" width="5" height="7" rx="2.5" fill="#0F172A" />
        {/* Taillight */}
        <rect x="7" y="42" width="4" height="1.8" rx="0.9" fill="#EF4444" />
      </svg>
    );
  }

  if (type === 'SUV') {
    return (
      <svg
        width={width}
        height={height}
        viewBox="0 0 32 50"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="transition-transform duration-150"
      >
        {/* Wide Side Mirrors */}
        <rect x="0.2" y="12" width="3" height="5.5" rx="1.5" fill={palette.body} stroke={palette.border} strokeWidth="0.6" />
        <rect x="28.8" y="12" width="3" height="5.5" rx="1.5" fill={palette.body} stroke={palette.border} strokeWidth="0.6" />
        {/* Main SUV Chassis */}
        <rect x="2.5" y="2" width="27" height="46" rx="7.5" fill={palette.body} stroke={palette.border} strokeWidth="0.9" />
        {/* Front Bumper & Grille */}
        <path d="M 6 3.5 Q 16 1.8 26 3.5" stroke={palette.accent} strokeWidth="0.9" fill="none" />
        {/* Dual LED Headlights */}
        <rect x="4" y="2.5" width="5.5" height="2.6" rx="1.3" fill={effectiveConfig.headlightsEnabled ? headlight.light : '#CBD5E1'} />
        <rect x="22.5" y="2.5" width="5.5" height="2.6" rx="1.3" fill={effectiveConfig.headlightsEnabled ? headlight.light : '#CBD5E1'} />
        {/* Front Windshield */}
        <path d="M 5.5 16 L 7.5 9 Q 16 7.5 24.5 9 L 26.5 16 Q 16 17.5 5.5 16 Z" fill="#0F172A" />
        {/* Roof Rails */}
        <line x1="7" y1="18" x2="7" y2="34" stroke="#475569" strokeWidth="1" strokeLinecap="round" />
        <line x1="25" y1="18" x2="25" y2="34" stroke="#475569" strokeWidth="1" strokeLinecap="round" />
        {/* Panoramic Glass Roof */}
        <rect x="9.5" y="18" width="13" height="15" rx="3" fill="#1E293B" opacity="0.9" />
        <line x1="9.5" y1="25.5" x2="22.5" y2="25.5" stroke="#334155" strokeWidth="0.8" />
        {/* Rear Windshield */}
        <path d="M 6.5 35 Q 16 33.5 25.5 35 L 24.5 40 Q 16 41 7.5 40 Z" fill="#0F172A" />
        {/* Rear Spoiler */}
        <line x1="7" y1="41" x2="25" y2="41" stroke={palette.accent} strokeWidth="1" />
        {/* Red Taillights */}
        <rect x="3.8" y="45.5" width="5.5" height="2.5" rx="1.2" fill="#EF4444" />
        <rect x="22.7" y="45.5" width="5.5" height="2.5" rx="1.2" fill="#EF4444" />
      </svg>
    );
  }

  if (type === 'VAN') {
    return (
      <svg
        width={width}
        height={height}
        viewBox="0 0 30 54"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="transition-transform duration-150"
      >
        {/* Mirrors */}
        <rect x="0.2" y="11" width="3" height="5" rx="1.5" fill={palette.body} stroke={palette.border} strokeWidth="0.6" />
        <rect x="26.8" y="11" width="3" height="5" rx="1.5" fill={palette.body} stroke={palette.border} strokeWidth="0.6" />
        {/* Van Chassis */}
        <rect x="2" y="2" width="26" height="50" rx="6" fill={palette.body} stroke={palette.border} strokeWidth="0.9" />
        {/* Headlights */}
        <rect x="3.5" y="2.5" width="5" height="2.5" rx="1.2" fill={effectiveConfig.headlightsEnabled ? headlight.light : '#CBD5E1'} />
        <rect x="21.5" y="2.5" width="5" height="2.5" rx="1.2" fill={effectiveConfig.headlightsEnabled ? headlight.light : '#CBD5E1'} />
        {/* Windshield */}
        <path d="M 4.5 15 L 6 8 Q 15 6.8 24 8 L 25.5 15 Q 15 16 4.5 15 Z" fill="#0F172A" />
        {/* Large VIP Van Roof Glass */}
        <rect x="6.5" y="17" width="17" height="23" rx="2" fill="#1E293B" opacity="0.9" />
        <line x1="6.5" y1="28" x2="23.5" y2="28" stroke="#334155" strokeWidth="0.8" />
        {/* Rear Windshield */}
        <path d="M 5 42 Q 15 41 25 42 L 24.5 47 Q 15 48 5.5 47 Z" fill="#0F172A" />
        {/* Taillights */}
        <rect x="3.5" y="49.5" width="5" height="2.4" rx="1.2" fill="#EF4444" />
        <rect x="21.5" y="49.5" width="5" height="2.4" rx="1.2" fill="#EF4444" />
      </svg>
    );
  }

  if (type === 'SPORT') {
    return (
      <svg
        width={width}
        height={height}
        viewBox="0 0 28 46"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="transition-transform duration-150"
      >
        {/* Mirrors */}
        <rect x="0.2" y="12" width="2.4" height="4.5" rx="1.2" fill={palette.body} stroke={palette.border} strokeWidth="0.5" />
        <rect x="25.4" y="12" width="2.4" height="4.5" rx="1.2" fill={palette.body} stroke={palette.border} strokeWidth="0.5" />
        {/* Aerodynamic Aerofoil Chassis */}
        <rect x="2" y="2" width="24" height="42" rx="7.5" fill={palette.body} stroke={palette.border} strokeWidth="0.8" />
        {/* Sport Vents on Bonnet */}
        <line x1="10" y1="5" x2="10" y2="7.5" stroke="#334155" strokeWidth="0.8" strokeLinecap="round" />
        <line x1="18" y1="5" x2="18" y2="7.5" stroke="#334155" strokeWidth="0.8" strokeLinecap="round" />
        {/* Angular Headlights */}
        <polygon points="3.5,4.5 8,2.8 7.5,5 3.5,5.5" fill={effectiveConfig.headlightsEnabled ? headlight.light : '#CBD5E1'} />
        <polygon points="24.5,4.5 20,2.8 20.5,5 24.5,5.5" fill={effectiveConfig.headlightsEnabled ? headlight.light : '#CBD5E1'} />
        {/* Sleek Windshield */}
        <path d="M 4.5 15 L 6.5 8.5 Q 14 7.2 21.5 8.5 L 23.5 15 Q 14 16.5 4.5 15 Z" fill="#0F172A" />
        {/* Cockpit Roof */}
        <rect x="6.5" y="17" width="15" height="12" rx="4" fill="#1E293B" />
        {/* Rear Fastback Window */}
        <path d="M 6 30 Q 14 28.5 22 30 L 20.5 35 Q 14 36 7.5 35 Z" fill="#0F172A" />
        {/* Rear Aerodynamic Wing / Spoiler */}
        <line x1="4" y1="39" x2="24" y2="39" stroke="#0F172A" strokeWidth="1.6" strokeLinecap="round" />
        {/* Quad Taillights */}
        <circle cx="5.5" cy="41" r="1.2" fill="#EF4444" />
        <circle cx="8" cy="41" r="1.2" fill="#EF4444" />
        <circle cx="20" cy="41" r="1.2" fill="#EF4444" />
        <circle cx="22.5" cy="41" r="1.2" fill="#EF4444" />
      </svg>
    );
  }

  if (type === 'BERLINE_LUXE') {
    return (
      <svg
        width={width}
        height={height}
        viewBox="0 0 28 52"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="transition-transform duration-150"
      >
        {/* Chrome Accent Mirrors */}
        <rect x="0.2" y="13" width="2.6" height="5" rx="1.3" fill={palette.body} stroke="#FBBF24" strokeWidth="0.7" />
        <rect x="25.2" y="13" width="2.6" height="5" rx="1.3" fill={palette.body} stroke="#FBBF24" strokeWidth="0.7" />
        {/* Elongated Luxury Wheelbase */}
        <rect x="2" y="2" width="24" height="48" rx="7" fill={palette.body} stroke="#FBBF24" strokeWidth="0.8" />
        {/* Chrome Bonnet Finisher */}
        <line x1="14" y1="2" x2="14" y2="9" stroke="#FBBF24" strokeWidth="0.8" />
        {/* Executive Headlights */}
        <rect x="3" y="2.8" width="4.8" height="2.4" rx="1.2" fill={effectiveConfig.headlightsEnabled ? headlight.light : '#CBD5E1'} />
        <rect x="20.2" y="2.8" width="4.8" height="2.4" rx="1.2" fill={effectiveConfig.headlightsEnabled ? headlight.light : '#CBD5E1'} />
        {/* Front Windshield */}
        <path d="M 4.8 16.5 L 6.5 9.5 Q 14 8 21.5 9.5 L 23.2 16.5 Q 14 17.5 4.8 16.5 Z" fill="#0F172A" />
        {/* Dual Sunroof (Executive) */}
        <rect x="7" y="18" width="14" height="6.5" rx="2" fill="#1E293B" stroke="#475569" strokeWidth="0.5" />
        <rect x="7" y="26" width="14" height="7.5" rx="2" fill="#1E293B" stroke="#475569" strokeWidth="0.5" />
        {/* Rear Windshield */}
        <path d="M 5.5 35 Q 14 34 22.5 35 L 21.5 40 Q 14 41 6.5 40 Z" fill="#0F172A" />
        {/* Chrome Rear Bar */}
        <line x1="5" y1="46" x2="23" y2="46" stroke="#FBBF24" strokeWidth="0.7" />
        {/* Taillights */}
        <rect x="3.2" y="47.2" width="4.8" height="2.2" rx="1.1" fill="#EF4444" />
        <rect x="20" y="47.2" width="4.8" height="2.2" rx="1.1" fill="#EF4444" />
      </svg>
    );
  }

  // DEFAULT: SEDAN (matches exactly the user's reference image: white body, yellow headlights, tinted front & rear glass, side mirrors, red rear taillights)
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 28 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="transition-transform duration-150"
    >
      {/* Side Mirrors */}
      <rect x="0.3" y="11.5" width="2.6" height="5" rx="1.3" fill={palette.body} stroke={palette.border} strokeWidth="0.6" />
      <rect x="25.1" y="11.5" width="2.6" height="5" rx="1.3" fill={palette.body} stroke={palette.border} strokeWidth="0.6" />

      {/* Main Car Body Chassis */}
      <rect x="2" y="2" width="24" height="44" rx="6.5" fill={palette.body} stroke={palette.border} strokeWidth="0.8" />

      {/* Front Bumper contour */}
      <path d="M 5 3.5 Q 14 2 23 3.5" stroke={palette.accent} strokeWidth="0.75" fill="none" />

      {/* Front Headlights (Yellow/Amber in image) */}
      <rect
        x="3.2"
        y="2.6"
        width="4.5"
        height="2.4"
        rx="1.2"
        fill={effectiveConfig.headlightsEnabled ? headlight.light : '#CBD5E1'}
      />
      <rect
        x="20.3"
        y="2.6"
        width="4.5"
        height="2.4"
        rx="1.2"
        fill={effectiveConfig.headlightsEnabled ? headlight.light : '#CBD5E1'}
      />

      {/* Front Tinted Windshield */}
      <path d="M 5 15.5 L 6.5 9 Q 14 7.8 21.5 9 L 23 15.5 Q 14 16.5 5 15.5 Z" fill="#1E293B" />

      {/* Windshield Gloss Highlight */}
      <path d="M 8 10 Q 14 9.2 18 10" stroke="#475569" strokeWidth="0.8" strokeLinecap="round" fill="none" />

      {/* Roof Lines */}
      <line x1="6.5" y1="17.5" x2="6.5" y2="29" stroke={palette.accent} strokeWidth="0.6" />
      <line x1="21.5" y1="17.5" x2="21.5" y2="29" stroke={palette.accent} strokeWidth="0.6" />

      {/* Rear Tinted Windshield */}
      <path d="M 5.8 30.5 Q 14 29.5 22.2 30.5 L 21.2 35 Q 14 36 6.8 35 Z" fill="#1E293B" />

      {/* Rear Bumper contour */}
      <path d="M 5 44.5 Q 14 46 23 44.5" stroke={palette.accent} strokeWidth="0.75" fill="none" />

      {/* Rear Red Taillights */}
      <rect x="3.2" y="43" width="4.5" height="2.4" rx="1.2" fill="#EF4444" />
      <rect x="20.3" y="43" width="4.5" height="2.4" rx="1.2" fill="#EF4444" />
    </svg>
  );
}

/**
 * Returns HTML string for Leaflet divIcon representing the customized top-down car
 */
export function getTopDownCarHtml(
  heading = 0,
  driverName?: string,
  isLive = false,
  size = 30,
  config?: Partial<DriverPictogramConfig>
): string {
  const effectiveConfig: DriverPictogramConfig = {
    ...DEFAULT_PICTOGRAM_CONFIG,
    ...config,
    size: size || config?.size || DEFAULT_PICTOGRAM_CONFIG.size,
  };

  const palette = COLOR_PALETTES[effectiveConfig.color] || COLOR_PALETTES.white;
  const headlight = HEADLIGHT_COLORS[effectiveConfig.headlightsColor || 'yellow'] || HEADLIGHT_COLORS.yellow;
  const height = Math.round((effectiveConfig.size * 48) / 28);
  const width = effectiveConfig.size;

  const nameHtml =
    effectiveConfig.showDriverTag && driverName
      ? `<div style="position: absolute; top: -22px; left: 50%; transform: translateX(-50%); background: ${
          isLive ? '#0f172a' : '#1e293b'
        }; color: white; font-weight: 700; font-size: 9px; padding: 2px 7px; border-radius: 9999px; box-shadow: 0 4px 10px rgba(0,0,0,0.5); white-space: nowrap; border: 1px solid ${
          isLive ? '#3b82f6' : 'rgba(255,255,255,0.2)'
        }; display: flex; align-items: center; gap: 4px;">
          <span style="width: 5px; height: 5px; border-radius: 9999px; background: #34d399;"></span>
          <span>${driverName}</span>
        </div>`
      : '';

  const pingHtml =
    isLive && effectiveConfig.haloPulse !== 'none'
      ? `<div style="position: absolute; inset: -8px; border-radius: 9999px; background: rgba(37,99,235,0.25); animation: ping 1.8s cubic-bezier(0, 0, 0.2, 1) infinite;"></div>`
      : '';

  const beamHtml =
    effectiveConfig.headlightsEnabled
      ? `<div style="position: absolute; top: -38px; left: 50%; transform: translateX(-50%); width: 50px; height: 42px; pointer-events: none; opacity: 0.8; background: radial-gradient(ellipse at 50% 100%, ${headlight.beam} 0%, rgba(255,255,255,0.06) 50%, transparent 80%); clip-path: polygon(35% 100%, 65% 100%, 100% 0%, 0% 0%);"></div>`
      : '';

  return `
    <div style="position: relative; width: ${width + 24}px; height: ${height + 24}px; display: flex; align-items: center; justify-content: center; cursor: pointer;">
      ${pingHtml}
      <div style="transform: rotate(${heading}deg); transform-origin: center center; filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.65)); transition: transform 0.35s ease-out; position: relative;">
        ${beamHtml}
        <svg width="${width}" height="${height}" viewBox="0 0 28 48" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="0.3" y="11.5" width="2.6" height="5" rx="1.3" fill="${palette.body}" stroke="${palette.border}" stroke-width="0.6"/>
          <rect x="25.1" y="11.5" width="2.6" height="5" rx="1.3" fill="${palette.body}" stroke="${palette.border}" stroke-width="0.6"/>
          <rect x="2" y="2" width="24" height="44" rx="6.5" fill="${palette.body}" stroke="${palette.border}" stroke-width="0.8"/>
          <path d="M 5 3.5 Q 14 2 23 3.5" stroke="${palette.accent}" stroke-width="0.75" fill="none"/>
          <rect x="3.2" y="2.6" width="4.5" height="2.4" rx="1.2" fill="${effectiveConfig.headlightsEnabled ? headlight.light : '#CBD5E1'}"/>
          <rect x="20.3" y="2.6" width="4.5" height="2.4" rx="1.2" fill="${effectiveConfig.headlightsEnabled ? headlight.light : '#CBD5E1'}"/>
          <path d="M 5 15.5 L 6.5 9 Q 14 7.8 21.5 9 L 23 15.5 Q 14 16.5 5 15.5 Z" fill="#1E293B"/>
          <path d="M 8 10 Q 14 9.2 18 10" stroke="#475569" stroke-width="0.8" stroke-linecap="round" fill="none"/>
          <line x1="6.5" y1="17.5" x2="6.5" y2="29" stroke="${palette.accent}" stroke-width="0.6"/>
          <line x1="21.5" y1="17.5" x2="21.5" y2="29" stroke="${palette.accent}" stroke-width="0.6"/>
          <path d="M 5.8 30.5 Q 14 29.5 22.2 30.5 L 21.2 35 Q 14 36 6.8 35 Z" fill="#1E293B"/>
          <path d="M 5 44.5 Q 14 46 23 44.5" stroke="${palette.accent}" stroke-width="0.75" fill="none"/>
          <rect x="3.2" y="43" width="4.5" height="2.4" rx="1.2" fill="#EF4444"/>
          <rect x="20.3" y="43" width="4.5" height="2.4" rx="1.2" fill="#EF4444"/>
        </svg>
      </div>
      ${nameHtml}
    </div>
  `;
}
