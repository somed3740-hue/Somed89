import React, { useEffect } from 'react';
import { Check } from 'lucide-react';
import { soundEffects } from '../../utils/audio';

interface LocationDisclosureModalProps {
  isOpen: boolean;
  onClose: () => void;
  onContinue: () => void;
}

/**
 * Modal "Use of your location"
 * Conforme à la charte et à la capture d'écran officielle (Image 2)
 * Affiche l'autorisation préalable d'accès à la localisation GPS
 */
export const LocationDisclosureModal: React.FC<LocationDisclosureModalProps> = ({
  isOpen,
  onClose,
  onContinue,
}) => {
  // Close on Escape key
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleContinueClick = () => {
    soundEffects.playClick();
    onContinue();
  };

  const handleNotNowClick = () => {
    soundEffects.playClick();
    onClose();
  };

  return (
    <div 
      className="fixed inset-0 z-[2600] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200 select-none"
      onClick={handleNotNowClick}
      role="dialog"
      aria-modal="true"
      aria-labelledby="location-disclosure-title"
    >
      <div 
        className="relative w-full max-w-[360px] bg-[#18191c] text-white rounded-[30px] p-6 sm:p-7 shadow-2xl border border-white/10 animate-in zoom-in-95 duration-150 flex flex-col items-center"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Center Circle Badge with Pin Icon */}
        <div className="w-20 h-20 rounded-full bg-[#2a2c16] flex items-center justify-center mb-5 ring-1 ring-yellow-400/20 shadow-lg shadow-black/40">
          <svg viewBox="0 0 24 24" className="w-10 h-10" fill="none" aria-hidden="true">
            <path 
              d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z" 
              fill="#FFE500"
            />
            <circle cx="12" cy="9" r="2.6" fill="#18191c" />
          </svg>
        </div>

        {/* Title */}
        <h3 
          id="location-disclosure-title"
          className="text-xl font-bold text-white text-center tracking-tight mb-3"
        >
          Use of your location
        </h3>

        {/* Paragraph Description */}
        <p className="text-sm text-neutral-300 text-left leading-relaxed w-full mb-4">
          SOMED collects your location data —even when the app is in the background— to:
        </p>

        {/* Checklist */}
        <div className="w-full space-y-3 mb-5">
          {/* Item 1 */}
          <div className="flex items-start gap-3">
            <div className="w-5 h-5 rounded-full bg-[#FFE500] flex items-center justify-center flex-shrink-0 mt-0.5 shadow-sm">
              <Check className="w-3.5 h-3.5 text-black stroke-[3]" />
            </div>
            <p className="text-xs sm:text-sm text-neutral-200 leading-snug">
              Detect your pickup point and show you nearby drivers
            </p>
          </div>

          {/* Item 2 */}
          <div className="flex items-start gap-3">
            <div className="w-5 h-5 rounded-full bg-[#FFE500] flex items-center justify-center flex-shrink-0 mt-0.5 shadow-sm">
              <Check className="w-3.5 h-3.5 text-black stroke-[3]" />
            </div>
            <p className="text-xs sm:text-sm text-neutral-200 leading-snug">
              Track your trip in real time, even with the app in the background
            </p>
          </div>
        </div>

        {/* Small Next Dialog Note */}
        <p className="text-xs text-neutral-400 text-center leading-relaxed mb-6 px-2">
          In the next dialog you can allow access to your location.
        </p>

        {/* Primary Yellow Button: Continue */}
        <button
          type="button"
          onClick={handleContinueClick}
          className="w-full py-4 px-4 bg-[#FFE500] hover:bg-[#ffea2e] active:scale-[0.98] text-black font-extrabold text-base rounded-2xl transition shadow-xl shadow-yellow-500/10 cursor-pointer flex items-center justify-center"
        >
          Continue
        </button>

        {/* Secondary Link Button: Not now */}
        <button
          type="button"
          onClick={handleNotNowClick}
          className="w-full py-2.5 mt-3 text-neutral-400 hover:text-white font-medium text-sm transition active:scale-95 cursor-pointer text-center"
        >
          Not now
        </button>
      </div>
    </div>
  );
};
