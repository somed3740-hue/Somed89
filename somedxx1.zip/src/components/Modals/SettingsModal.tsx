import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  Bell, 
  Moon, 
  Sun,
  Smartphone,
  Trash2, 
  ChevronRight, 
  Map, 
  Key, 
  CheckCircle2, 
  AlertCircle,
  HelpCircle,
  X,
  FileSpreadsheet
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { PictogramCustomizerModal } from './PictogramCustomizerModal';
import { DeleteAccountModal } from './DeleteAccountModal';
import { exportPassengerRGPDToExcel } from '../../utils/rgpdExcelExport';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenNotifications: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  onOpenNotifications,
}) => {
  const isLight = vtcStore.isLightMode();
  const passenger = vtcStore.getPassenger();
  const [testKey, setTestKey] = useState(passenger.mapsApiKey || 'AIzaSyDoekxnWyaYO0OgRyjpyRZMc_D_fP4ABug');
  const [mapEngine, setMapEngine] = useState<'leaflet' | 'google'>(passenger.mapEngine || 'google');
  const [keyStatus, setKeyStatus] = useState<'IDLE' | 'TESTING' | 'VALID' | 'ERROR'>('IDLE');
  const [showLicenseModal, setShowLicenseModal] = useState(false);
  const [isPictogramOpen, setIsPictogramOpen] = useState(false);
  const [showDeleteAccountModal, setShowDeleteAccountModal] = useState(false);
  const [hasExportedExcel, setHasExportedExcel] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setTestKey(passenger.mapsApiKey || 'AIzaSyDoekxnWyaYO0OgRyjpyRZMc_D_fP4ABug');
      setMapEngine(passenger.mapEngine || 'google');
    }
  }, [isOpen, passenger.mapsApiKey, passenger.mapEngine]);

  if (!isOpen) return null;

  const handleSaveMapSettings = () => {
    vtcStore.setMapEngine(mapEngine, testKey);
    setKeyStatus('TESTING');
    setTimeout(() => {
      setKeyStatus('VALID');
      setTimeout(() => setKeyStatus('IDLE'), 3000);
    }, 600);
  };

  const handleAppearanceChange = (mode: 'light' | 'dark' | 'auto') => {
    vtcStore.setAppearance(mode);
  };

  return (
    <div className="fixed inset-0 z-[1250] flex flex-col select-none animate-in fade-in duration-200">
      <div 
        className={`h-full w-full flex flex-col overflow-y-auto transition-colors ${
          isLight ? 'bg-slate-50 text-slate-900' : 'bg-black text-white'
        }`}
      >
        {/* Top Header (Screenshot 12) */}
        <header className={`px-5 py-4 border-b flex items-center justify-between flex-shrink-0 sticky top-0 backdrop-blur-md z-20 ${
          isLight ? 'border-slate-200 bg-white/95' : 'border-neutral-900 bg-black/95'
        }`}>
          <button
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="font-bold text-base">Settings</h2>
          <div className="w-9" />
        </header>

        {/* Main Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-6 max-w-md mx-auto w-full">
          {/* Account Section (Screenshot 12) */}
          <div className="space-y-2">
            <h3 className={`text-xs font-semibold ${isLight ? 'text-slate-500' : 'text-neutral-500'}`}>Account</h3>
            <div className={`rounded-2xl border overflow-hidden ${
              isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
            }`}>
              <button
                onClick={onOpenNotifications}
                className={`w-full p-4 flex items-center justify-between transition group text-left ${
                  isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  <Bell className="w-5 h-5 text-neutral-400 group-hover:text-yellow-400" />
                  <div>
                    <p className="font-bold text-sm">Notification preferences</p>
                    <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                      Configure which notifications to receive
                    </p>
                  </div>
                </div>
                <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-neutral-600'}`} />
              </button>
            </div>
          </div>

          {/* Appearance Section (Clair / Sombre / Auto - Requested by User) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h3 className={`text-xs font-semibold ${isLight ? 'text-slate-500' : 'text-neutral-500'}`}>Appearance</h3>
              <span className="text-[11px] font-bold text-yellow-500 uppercase tracking-wider">
                {passenger.appearance === 'light' ? 'Mode Clair actif' : passenger.appearance === 'dark' ? 'Mode Sombre actif' : 'Automatique'}
              </span>
            </div>

            <div className={`p-4 rounded-2xl border space-y-3 ${
              isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
            }`}>
              <div className="flex items-center gap-3.5">
                {isLight ? (
                  <Sun className="w-5 h-5 text-amber-500" />
                ) : (
                  <Moon className="w-5 h-5 text-neutral-400" />
                )}
                <div>
                  <p className="font-bold text-sm">Thème d'affichage</p>
                  <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                    Cliquez sur Light pour passer en clair, ou Dark pour passer en sombre
                  </p>
                </div>
              </div>

              {/* 3 Interactive Buttons */}
              <div className={`grid grid-cols-3 gap-2 p-1.5 rounded-xl border ${
                isLight ? 'bg-slate-100 border-slate-200' : 'bg-neutral-900 border-neutral-800'
              }`}>
                <button
                  type="button"
                  onClick={() => handleAppearanceChange('light')}
                  className={`py-2.5 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition ${
                    passenger.appearance === 'light'
                      ? 'bg-yellow-400 text-black shadow-md'
                      : isLight ? 'text-slate-600 hover:text-black' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  <Sun className="w-3.5 h-3.5" />
                  <span>Light</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleAppearanceChange('dark')}
                  className={`py-2.5 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition ${
                    passenger.appearance === 'dark'
                      ? 'bg-yellow-400 text-black shadow-md'
                      : isLight ? 'text-slate-600 hover:text-black' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  <Moon className="w-3.5 h-3.5" />
                  <span>Dark</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleAppearanceChange('auto')}
                  className={`py-2.5 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition ${
                    passenger.appearance === 'auto'
                      ? 'bg-yellow-400 text-black shadow-md'
                      : isLight ? 'text-slate-600 hover:text-black' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>Auto</span>
                </button>
              </div>
            </div>
          </div>

          {/* Map Engine & Test API Key */}
          <div className="space-y-2">
            <h3 className={`text-xs font-semibold ${isLight ? 'text-slate-500' : 'text-neutral-500'}`}>
              Cartographie & Clé API Maps
            </h3>
            <div className={`p-4 rounded-2xl border space-y-4 ${
              isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
            }`}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-yellow-400/20 border border-yellow-400/40 text-yellow-500 flex items-center justify-center flex-shrink-0">
                  <Map className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-bold text-sm">Moteur de carte</p>
                  <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                    Sélectionnez le provider cartographique
                  </p>
                </div>
              </div>

              {/* Engine choice */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setMapEngine('google')}
                  className={`py-2 px-3 rounded-xl text-xs font-bold border transition ${
                    mapEngine === 'google'
                      ? 'bg-yellow-400 text-black border-yellow-400'
                      : isLight 
                      ? 'bg-slate-100 text-slate-700 border-slate-200' 
                      : 'bg-neutral-900 text-neutral-400 border-neutral-800'
                  }`}
                >
                  Google Maps (Recommandé)
                </button>
                <button
                  type="button"
                  onClick={() => setMapEngine('leaflet')}
                  className={`py-2 px-3 rounded-xl text-xs font-bold border transition ${
                    mapEngine === 'leaflet'
                      ? 'bg-yellow-400 text-black border-yellow-400'
                      : isLight 
                      ? 'bg-slate-100 text-slate-700 border-slate-200' 
                      : 'bg-neutral-900 text-neutral-400 border-neutral-800'
                  }`}
                >
                  Leaflet HD (Secours)
                </button>
              </div>

              {/* Test API Key input */}
              <div className="space-y-1.5 pt-1">
                <label className={`text-xs font-semibold flex items-center justify-between ${
                  isLight ? 'text-slate-600' : 'text-neutral-400'
                }`}>
                  <span>Clé API Maps (Test / Prod)</span>
                  <span className="text-[10px] text-yellow-500 font-mono">Prête à l'emploi</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={testKey}
                    onChange={(e) => setTestKey(e.target.value)}
                    placeholder="AIzaSy..."
                    className={`w-full border rounded-xl pl-3.5 pr-20 py-2.5 text-xs font-mono focus:outline-none focus:border-yellow-400 ${
                      isLight 
                        ? 'bg-slate-100 border-slate-300 text-slate-900 placeholder-slate-400' 
                        : 'bg-neutral-900 border-neutral-800 text-white placeholder-neutral-500'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={handleSaveMapSettings}
                    className="absolute right-1.5 top-1.5 px-2.5 py-1.5 bg-yellow-400 text-black rounded-lg font-bold text-[10px] hover:bg-yellow-300 transition"
                  >
                    {keyStatus === 'TESTING' ? 'Test...' : 'Valider'}
                  </button>
                </div>

                {keyStatus === 'VALID' && (
                  <p className="text-[11px] text-emerald-500 font-semibold flex items-center gap-1 mt-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Clé API Maps enregistrée avec succès !</span>
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Pictogramme Chauffeur & Véhicule GPS */}
          <div className="space-y-2">
            <h3 className={`text-xs font-semibold ${isLight ? 'text-slate-500' : 'text-neutral-500'}`}>
              Pictogramme Chauffeur & Véhicule GPS
            </h3>
            <div className={`p-4 rounded-2xl border space-y-3 ${
              isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
            }`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-yellow-400/20 border border-yellow-400/40 text-yellow-500 flex items-center justify-center flex-shrink-0 text-xl">
                    🚗
                  </div>
                  <div>
                    <p className="font-bold text-sm">Pictogramme sur la carte</p>
                    <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                      Personnalisez l'apparence des véhicules en déplacement réel
                    </p>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsPictogramOpen(true)}
                className="w-full py-2.5 px-3 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-xs flex items-center justify-center gap-2 transition active:scale-95 shadow-md shadow-yellow-400/20"
              >
                <span>🎨 Personnaliser le pictogramme GPS</span>
              </button>
            </div>
          </div>

          {/* Gestion du compte & Données personnelles (sans mention zone de danger) */}
          <div className="space-y-2">
            <h3 className={`text-xs font-semibold ${isLight ? 'text-slate-500' : 'text-neutral-500'}`}>
              Données personnelles & Compte
            </h3>
            <div className={`rounded-2xl border divide-y overflow-hidden ${
              isLight ? 'bg-white border-slate-200 divide-slate-100' : 'bg-neutral-950 border-neutral-900 divide-neutral-900'
            }`}>
              {/* Export RGPD au format Excel */}
              <button
                type="button"
                onClick={() => {
                  exportPassengerRGPDToExcel(vtcStore.getPassenger());
                  setHasExportedExcel(true);
                }}
                className={`w-full p-4 flex items-center justify-between transition group text-left ${
                  isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center flex-shrink-0">
                    <FileSpreadsheet className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-sm block">Exporter conformité RGPD (Excel)</span>
                    <span className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                      {hasExportedExcel ? 'Fichier .xlsx téléchargé' : 'Télécharger vos données sous forme de tableur Excel'}
                    </span>
                  </div>
                </div>
                {hasExportedExcel ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                ) : (
                  <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-neutral-600'}`} />
                )}
              </button>

              {/* Suppression de compte en texte clair */}
              <button
                type="button"
                onClick={() => setShowDeleteAccountModal(true)}
                className={`w-full p-4 flex items-center justify-between transition group text-left ${
                  isLight ? 'hover:bg-rose-50/50' : 'hover:bg-rose-950/10'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-8 h-8 rounded-xl bg-rose-500/10 text-rose-500 flex items-center justify-center flex-shrink-0">
                    <Trash2 className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-sm text-rose-500 block">Supprimer mon compte</span>
                    <span className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                      Suppression définitive de vos données et historiques
                    </span>
                  </div>
                </div>
                <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-neutral-600'}`} />
              </button>
            </div>
          </div>

          {/* Footer (Screenshot 12) */}
          <div className="pt-4 text-center space-y-2">
            <p className={`text-xs font-mono ${isLight ? 'text-slate-500' : 'text-neutral-500'}`}>
              SOMED v1.0.2 (#3) — SOMED
            </p>
            <button
              onClick={() => setShowLicenseModal(true)}
              className="text-xs font-bold text-yellow-500 hover:underline"
            >
              Software licenses
            </button>
          </div>
        </div>

        {/* Software licenses dialog */}
        {showLicenseModal && (
          <div className="fixed inset-0 z-[1300] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <div className={`border rounded-3xl w-full max-w-sm p-6 shadow-2xl space-y-4 ${
              isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
            }`}>
              <div className={`flex items-center justify-between pb-2 border-b ${
                isLight ? 'border-slate-200' : 'border-neutral-900'
              }`}>
                <h3 className="font-bold text-base">Software licenses</h3>
                <button
                  onClick={() => setShowLicenseModal(false)}
                  className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    isLight ? 'bg-slate-200 text-slate-700' : 'bg-neutral-900 text-neutral-400'
                  }`}
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className={`text-xs space-y-2 max-h-60 overflow-y-auto ${
                isLight ? 'text-slate-600' : 'text-neutral-400'
              }`}>
                <p>SOMED VTC Platform & Mobility Suite</p>
                <p>Copyright © 2026 SOMED Inc. All rights reserved.</p>
                <p>Leaflet & OpenStreetMap (BSD / ODbL)</p>
                <p>Lucide Icons (ISC License)</p>
                <p>Firebase SDK (Apache 2.0)</p>
              </div>
            </div>
          </div>
        )}
      </div>

      <PictogramCustomizerModal
        isOpen={isPictogramOpen}
        onClose={() => setIsPictogramOpen(false)}
      />

      <DeleteAccountModal
        isOpen={showDeleteAccountModal}
        onClose={() => setShowDeleteAccountModal(false)}
        userType="passenger"
        onAccountDeleted={() => {
          setShowDeleteAccountModal(false);
          onClose();
        }}
      />
    </div>
  );
};
