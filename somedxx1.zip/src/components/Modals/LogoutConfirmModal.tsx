import React, { useEffect } from 'react';
import { soundEffects } from '../../utils/audio';

interface LogoutConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
}

export const LogoutConfirmModal: React.FC<LogoutConfirmModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
}) => {
  // Close on Escape key
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleCancel = () => {
    soundEffects.playClick();
    onClose();
  };

  const handleConfirm = () => {
    soundEffects.playClick();
    onConfirm();
  };

  return (
    <div 
      className="fixed inset-0 z-[2500] flex items-center justify-center p-4 bg-black/75 backdrop-blur-[2px] animate-in fade-in duration-150 select-none"
      onClick={handleCancel}
      role="dialog"
      aria-modal="true"
      aria-labelledby="logout-confirm-title"
    >
      <div 
        className="relative w-full max-w-[320px] bg-[#1c1c1e] text-white rounded-[26px] p-6 shadow-2xl border border-white/10 animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Title */}
        <h3 
          id="logout-confirm-title" 
          className="text-xl font-bold text-white text-left tracking-normal"
        >
          Log out
        </h3>

        {/* Subtitle / Question */}
        <p className="text-sm text-neutral-400 text-left mt-3 leading-relaxed">
          Are you sure you want to log out?
        </p>

        {/* Cancel Button (Right-aligned in yellow above main button as in screenshot) */}
        <div className="flex justify-end mt-7 mb-4">
          <button
            type="button"
            onClick={handleCancel}
            className="text-[#FFE500] hover:text-[#fff066] active:opacity-70 font-semibold text-sm transition cursor-pointer px-1 py-0.5"
          >
            Cancel
          </button>
        </div>

        {/* Big Yellow Log Out Button */}
        <button
          type="button"
          onClick={handleConfirm}
          className="w-full py-3.5 px-4 bg-[#FFE500] hover:bg-[#ffeb3b] active:scale-[0.98] text-black font-bold text-base rounded-2xl transition shadow-lg flex items-center justify-center cursor-pointer"
        >
          Log out
        </button>
      </div>
    </div>
  );
};
