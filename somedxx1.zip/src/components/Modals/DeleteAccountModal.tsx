import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Trash2, 
  AlertTriangle, 
  ShieldAlert, 
  CheckCircle2, 
  Download, 
  Lock,
  Wallet,
  Car,
  FileText,
  UserX,
  FileSpreadsheet
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { soundEffects } from '../../utils/audio';
import { exportPassengerRGPDToExcel, exportDriverRGPDToExcel } from '../../utils/rgpdExcelExport';

interface DeleteAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  userType: 'passenger' | 'driver';
  onAccountDeleted?: () => void;
}

export const DeleteAccountModal: React.FC<DeleteAccountModalProps> = ({
  isOpen,
  onClose,
  userType,
  onAccountDeleted,
}) => {
  const isLight = vtcStore.isLightMode();
  const passenger = vtcStore.getPassenger();
  const driver = vtcStore.getCurrentDriver();

  const [hasAcknowledged, setHasAcknowledged] = useState(false);
  const [selectedReason, setSelectedReason] = useState<string>('');
  const [customReason, setCustomReason] = useState<string>('');
  const [isDeleting, setIsDeleting] = useState(false);
  const [hasExported, setHasExported] = useState(false);
  const [step, setStep] = useState<'details' | 'success'>('details');

  if (!isOpen) return null;

  const reasonsPassenger = [
    { id: 'expensive', label: "Tarifs ou frais trop élevés" },
    { id: 'not_needed', label: "Je n'ai plus besoin de l'application" },
    { id: 'switch_service', label: "J'utilise un autre service de transport" },
    { id: 'privacy', label: "Préoccupations liées à la confidentialité des données" },
    { id: 'technical', label: "Problèmes techniques récurrents" },
    { id: 'other', label: "Autre raison" },
  ];

  const reasonsDriver = [
    { id: 'commission', label: "Taux de commission ou rentabilité insuffisante" },
    { id: 'stopped_vtc', label: "Arrêt définitif de l'activité VTC / Taxi" },
    { id: 'switch_platform', label: "Je privilégie une autre plateforme partenaire" },
    { id: 'documents', label: "Difficultés de validation administrative" },
    { id: 'other', label: "Autre raison" },
  ];

  const reasons = userType === 'driver' ? reasonsDriver : reasonsPassenger;

  const handleExportData = () => {
    soundEffects.playClick();
    if (userType === 'driver') {
      exportDriverRGPDToExcel(driver);
    } else {
      exportPassengerRGPDToExcel(passenger);
    }
    setHasExported(true);
  };

  const handleDeleteAccount = () => {
    if (!hasAcknowledged) return;
    setIsDeleting(true);
    soundEffects.playClick();

    setTimeout(() => {
      if (userType === 'driver') {
        vtcStore.deleteDriverAccount(driver.id, selectedReason);
      } else {
        vtcStore.deletePassengerAccount(selectedReason);
      }

      setIsDeleting(false);
      setStep('success');

      setTimeout(() => {
        onAccountDeleted?.();
        onClose();
      }, 2200);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-[1350] flex flex-col select-none animate-in fade-in duration-200">
      <div 
        className={`h-full w-full flex flex-col overflow-y-auto transition-colors ${
          isLight ? 'bg-slate-50 text-slate-900' : 'bg-black text-white'
        }`}
      >
        {/* Header */}
        <header className={`px-5 py-4 border-b flex items-center justify-between sticky top-0 backdrop-blur-md z-20 ${
          isLight ? 'border-slate-200 bg-white/95' : 'border-neutral-900 bg-black/95'
        }`}>
          <button
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="text-center">
            <h2 className="font-bold text-base text-rose-500 flex items-center gap-1.5 justify-center">
              <Trash2 className="w-4 h-4" />
              <span>{userType === 'driver' ? 'Supprimer le compte chauffeur' : 'Supprimer mon compte'}</span>
            </h2>
          </div>
          <div className="w-9" />
        </header>

        {/* Success Screen */}
        {step === 'success' ? (
          <div className="flex-1 flex flex-col items-center justify-center p-6 text-center max-w-md mx-auto space-y-4 animate-in zoom-in-95">
            <div className="w-20 h-20 rounded-full bg-rose-500/10 border-2 border-rose-500/30 flex items-center justify-center text-rose-500">
              <UserX className="w-10 h-10 animate-bounce" />
            </div>
            <h3 className="text-xl font-black">Compte supprimé avec succès</h3>
            <p className={`text-sm ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>
              Vos données personnelles, historiques et identifiants ont été clôturés sur la plateforme SOMED.
            </p>
            <div className="w-8 h-8 border-2 border-rose-500 border-t-transparent rounded-full animate-spin mt-4" />
          </div>
        ) : (
          /* Main Content */
          <div className="flex-1 max-w-md mx-auto w-full p-5 space-y-5">
            
            {/* Titre et détails du compte en écriture textuelle claire (sans image ni badge zone de danger) */}
            <div className={`p-5 rounded-3xl border space-y-3 ${
              isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-neutral-950 border-neutral-800'
            }`}>
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-rose-500 uppercase tracking-wider">
                  Action définitive & irréversible
                </span>
                <span className={`text-[11px] font-mono px-2 py-0.5 rounded-md ${
                  isLight ? 'bg-slate-100 text-slate-500' : 'bg-neutral-900 text-neutral-400'
                }`}>
                  {userType === 'driver' ? `Réf: ${driver.id}` : `Réf: ${passenger.id}`}
                </span>
              </div>
              
              <h3 className="text-lg font-black tracking-tight">
                {userType === 'driver' ? 'Clôture et suppression du compte chauffeur' : 'Suppression définitive de votre compte'}
              </h3>

              <div className={`text-xs space-y-1 p-3 rounded-2xl ${
                isLight ? 'bg-slate-50 text-slate-700' : 'bg-neutral-900 text-neutral-300'
              }`}>
                <p className="font-bold text-sm">
                  {userType === 'driver' ? driver.name : passenger.name}
                </p>
                <p>
                  {userType === 'driver' 
                    ? `Téléphone : ${driver.phone} · Véhicule : ${driver.vehicle.model} (${driver.vehicle.plate})` 
                    : `Téléphone : ${passenger.phone} · Email : ${passenger.email || 'contact@somed.biz'}`}
                </p>
              </div>
            </div>

            {/* Warning Alert Banner */}
            <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-start gap-3 text-rose-400">
              <AlertTriangle className="w-5 h-5 flex-shrink-0 mt-0.5 text-rose-500" />
              <div className="text-xs space-y-1">
                <p className="font-bold text-rose-500 text-sm">Attention : action définitive</p>
                <p className={`${isLight ? 'text-slate-700' : 'text-neutral-300'}`}>
                  Une fois votre compte supprimé, toutes vos données seront immédiatement désactivées et irrécupérables.
                </p>
              </div>
            </div>

            {/* What you will lose */}
            <div className={`p-4 rounded-3xl border space-y-3 ${
              isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
            }`}>
              <h4 className="font-bold text-xs uppercase tracking-wider text-rose-500 flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4" />
                <span>Ce qui sera définitivement supprimé</span>
              </h4>

              <div className="space-y-2.5 text-xs">
                {userType === 'passenger' ? (
                  <>
                    <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-rose-500/5 border border-rose-500/10">
                      <Wallet className="w-4 h-4 text-rose-400 flex-shrink-0" />
                      <div>
                        <span className="font-bold">Solde portefeuille : </span>
                        <span className="text-rose-400 font-extrabold">{passenger.walletBalance.toFixed(2)} EUR</span>
                        <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                          Ce montant sera définitivement perdu si non utilisé.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-rose-500/5 border border-rose-500/10">
                      <FileText className="w-4 h-4 text-rose-400 flex-shrink-0" />
                      <div>
                        <span className="font-bold">Historique complet des courses : </span>
                        <span>{passenger.tripsCount} courses et reçus associés</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-rose-500/5 border border-rose-500/10">
                      <Lock className="w-4 h-4 text-rose-400 flex-shrink-0" />
                      <div>
                        <span className="font-bold">Moyens de paiement & Lieux favoris : </span>
                        <span>Toutes vos adresses enregistrées et cartes bancaires</span>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-rose-500/5 border border-rose-500/10">
                      <Wallet className="w-4 h-4 text-rose-400 flex-shrink-0" />
                      <div>
                        <span className="font-bold">Gains & Solde chauffeur : </span>
                        <span className="text-rose-400 font-extrabold">{(driver.driverWalletBalance || 0).toFixed(2)} EUR</span>
                        <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                          Tous les virements en cours seront interrompus.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-rose-500/5 border border-rose-500/10">
                      <FileText className="w-4 h-4 text-rose-400 flex-shrink-0" />
                      <div>
                        <span className="font-bold">Dossier réglementaire VTC & Taxi : </span>
                        <span>Suppression des {(driver.documentsList || []).length} documents professionnels validés</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-rose-500/5 border border-rose-500/10">
                      <Car className="w-4 h-4 text-rose-400 flex-shrink-0" />
                      <div>
                        <span className="font-bold">Véhicule partenaire & Dispatch : </span>
                        <span>Déréférencement du véhicule {driver.vehicle.plate}</span>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* RGPD Export Button sous forme EXCEL (.xlsx) */}
            <div className={`p-4 rounded-3xl border flex items-center justify-between gap-3 ${
              isLight ? 'bg-emerald-50/70 border-emerald-200' : 'bg-emerald-950/20 border-emerald-800/40'
            }`}>
              <div className="space-y-0.5">
                <div className="flex items-center gap-1.5">
                  <FileSpreadsheet className="w-4 h-4 text-emerald-500" />
                  <p className="font-bold text-xs text-emerald-500">Conformité RGPD · Export Excel (.xlsx)</p>
                </div>
                <p className={`text-[11px] ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>
                  {hasExported ? 'Classeur Excel téléchargé avec succès' : 'Téléchargez l’intégralité de vos données sous tableur Excel'}
                </p>
              </div>
              <button
                type="button"
                onClick={handleExportData}
                className={`py-2 px-3.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition active:scale-95 flex-shrink-0 ${
                  hasExported 
                    ? 'bg-emerald-600 text-white' 
                    : 'bg-emerald-500 hover:bg-emerald-400 text-white shadow-md shadow-emerald-500/20'
                }`}
              >
                {hasExported ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Download className="w-3.5 h-3.5" />}
                <span>{hasExported ? 'Téléchargé' : 'Exporter en Excel'}</span>
              </button>
            </div>

            {/* Reason Selection */}
            <div className={`p-4 rounded-3xl border space-y-3 ${
              isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
            }`}>
              <h4 className="font-bold text-xs">Pourquoi nous quittez-vous ? (facultatif)</h4>
              <div className="space-y-1.5">
                {reasons.map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => setSelectedReason(r.id)}
                    className={`w-full p-2.5 rounded-xl text-xs text-left border flex items-center justify-between transition ${
                      selectedReason === r.id
                        ? 'border-yellow-400 bg-yellow-400/10 text-yellow-400 font-bold'
                        : isLight ? 'border-slate-200 hover:bg-slate-50 text-slate-700' : 'border-neutral-800 hover:bg-neutral-900 text-neutral-300'
                    }`}
                  >
                    <span>{r.label}</span>
                    {selectedReason === r.id && <CheckCircle2 className="w-4 h-4 text-yellow-400" />}
                  </button>
                ))}
              </div>

              {selectedReason === 'other' && (
                <input
                  type="text"
                  placeholder="Précisez la raison..."
                  value={customReason}
                  onChange={(e) => setCustomReason(e.target.value)}
                  className={`w-full p-3 rounded-xl text-xs border outline-none ${
                    isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900 border-neutral-800 text-white'
                  }`}
                />
              )}
            </div>

            {/* Acknowledgment Checkbox */}
            <label className={`p-4 rounded-3xl border flex items-start gap-3 cursor-pointer transition select-none ${
              hasAcknowledged
                ? 'border-rose-500 bg-rose-500/10'
                : isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
            }`}>
              <input
                type="checkbox"
                checked={hasAcknowledged}
                onChange={(e) => {
                  soundEffects.playClick();
                  setHasAcknowledged(e.target.checked);
                }}
                className="mt-0.5 w-4 h-4 rounded text-rose-600 focus:ring-rose-500"
              />
              <span className="text-xs font-semibold leading-relaxed">
                Je confirme avoir pris connaissance des conséquences et renoncer définitivement à mon compte, solde restant et avantages SOMED.
              </span>
            </label>

            {/* Action Buttons */}
            <div className="pt-2 space-y-2.5 pb-6">
              <button
                type="button"
                disabled={!hasAcknowledged || isDeleting}
                onClick={handleDeleteAccount}
                className={`w-full py-4 rounded-2xl font-extrabold text-sm flex items-center justify-center gap-2 transition shadow-xl active:scale-95 ${
                  hasAcknowledged && !isDeleting
                    ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-600/30'
                    : 'bg-rose-950/30 text-rose-500/40 border border-rose-900/40 cursor-not-allowed'
                }`}
              >
                {isDeleting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Suppression définitive en cours...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    <span>Confirmer la suppression définitive</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={onClose}
                className={`w-full py-3.5 rounded-2xl text-xs font-bold border transition active:scale-95 ${
                  isLight 
                    ? 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-800' 
                    : 'bg-neutral-900 hover:bg-neutral-800 border-neutral-800 text-neutral-300'
                }`}
              >
                Annuler et conserver mon compte
              </button>
            </div>

          </div>
        )}
      </div>
    </div>
  );
};
