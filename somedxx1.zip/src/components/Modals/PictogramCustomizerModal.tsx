import React, { useState, useEffect } from 'react';
import { 
  X, 
  RotateCw, 
  RotateCcw, 
  Compass, 
  Sun, 
  Sparkles, 
  Car, 
  ShieldCheck, 
  Check, 
  Play, 
  Pause,
  Sliders,
  Palette,
  Eye,
  Zap
} from 'lucide-react';
import { 
  TopDownCarMarker, 
  DEFAULT_PICTOGRAM_CONFIG, 
  COLOR_PALETTES, 
  HEADLIGHT_COLORS 
} from '../Map/TopDownCarMarker';
import { DriverPictogramConfig, VehicleColorPreset, VehiclePictogramType, HaloPulseStyle, DriverProfile } from '../../types/vtc';
import { vtcStore } from '../../services/vtcStore';
import { soundEffects } from '../../utils/audio';

interface PictogramCustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  driverId?: string;
  onSaved?: (newConfig: DriverPictogramConfig) => void;
}

export const PictogramCustomizerModal: React.FC<PictogramCustomizerModalProps> = ({
  isOpen,
  onClose,
  driverId,
  onSaved,
}) => {
  const isLight = vtcStore.isLightMode();
  const currentDriver = driverId 
    ? vtcStore.getAllDrivers().find((d: DriverProfile) => d.id === driverId) || vtcStore.getCurrentDriver()
    : vtcStore.getCurrentDriver();

  const [config, setConfig] = useState<DriverPictogramConfig>(() => {
    return currentDriver.pictogramConfig || DEFAULT_PICTOGRAM_CONFIG;
  });

  const [previewHeading, setPreviewHeading] = useState<number>(0);
  const [isSimulatingDriving, setIsSimulatingDriving] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);

  // Sync when modal opens or driver changes
  useEffect(() => {
    if (isOpen) {
      setConfig(currentDriver.pictogramConfig || DEFAULT_PICTOGRAM_CONFIG);
      setPreviewHeading(currentDriver.heading || 0);
      setIsSimulatingDriving(false);
      setSaveSuccess(false);
    }
  }, [isOpen, currentDriver.id]);

  // Motion simulation loop for test drive
  useEffect(() => {
    if (!isSimulatingDriving) return;

    const interval = setInterval(() => {
      setPreviewHeading((prev) => (prev + 4) % 360);
    }, 100);

    return () => clearInterval(interval);
  }, [isSimulatingDriving]);

  if (!isOpen) return null;

  const vehicleModels: { type: VehiclePictogramType; title: string; subtitle: string; icon: string }[] = [
    { type: 'SEDAN', title: 'Berline Standard', subtitle: 'Style référence (Blanc & Phares jaunes)', icon: '🚗' },
    { type: 'BERLINE_LUXE', title: 'Berline Prestige VIP', subtitle: 'Mercedes Maybach & finitions or', icon: '✨' },
    { type: 'SUV', title: 'SUV Prestige', subtitle: 'Robuste, barres de toit & double toit', icon: '🚙' },
    { type: 'VAN', title: 'Minibus / Van VIP', subtitle: 'Spacieux Mercedes Classe V', icon: '🚐' },
    { type: 'SPORT', title: 'Sportive GT', subtitle: 'Aérodynamique agressive & diffuseur', icon: '🏎️' },
    { type: 'MOTO', title: 'Moto Express', subtitle: 'Coursier & déplacement rapide', icon: '🏍️' },
  ];

  const haloOptions: { id: HaloPulseStyle; label: string; color: string }[] = [
    { id: 'blue', label: 'Bleu Néon GPS', color: 'bg-blue-500' },
    { id: 'gold', label: 'Or SOMED Prestige', color: 'bg-amber-400' },
    { id: 'emerald', label: 'Vert Émeraude', color: 'bg-emerald-500' },
    { id: 'none', label: 'Désactivé', color: 'bg-slate-500' },
  ];

  const handleApply = () => {
    soundEffects.playSuccessSound();
    vtcStore.updateDriverPictogramConfig(currentDriver.id, config);
    setSaveSuccess(true);
    onSaved?.(config);

    vtcStore.sendPushNotification({
      title: 'Pictogramme GPS personnalisé !',
      body: `Le véhicule de ${currentDriver.name} (${COLOR_PALETTES[config.color]?.name || config.color}) est actif sur la carte en temps réel.`,
      category: 'RIDE',
      badge: 'GPS VÉHICULE',
    });

    setTimeout(() => {
      setSaveSuccess(false);
      onClose();
    }, 700);
  };

  const handleResetDefault = () => {
    soundEffects.playClick();
    setConfig(DEFAULT_PICTOGRAM_CONFIG);
    setPreviewHeading(0);
  };

  return (
    <div className="fixed inset-0 z-[1350] flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md select-none animate-in fade-in duration-200">
      <div 
        className={`w-full max-w-xl max-h-[92vh] flex flex-col rounded-3xl border shadow-2xl overflow-hidden transition-all duration-200 ${
          isLight ? 'bg-white border-slate-200 text-slate-900 shadow-slate-300' : 'bg-neutral-950 border-neutral-800 text-white'
        }`}
      >
        {/* Header */}
        <header className={`px-5 py-4 border-b flex items-center justify-between flex-shrink-0 ${
          isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/90 border-neutral-800'
        }`}>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-yellow-400/20 text-yellow-500 flex items-center justify-center border border-yellow-400/40">
              <Car className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base leading-tight">Personnaliser le Pictogramme Chauffeur</h2>
              <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                Véhicule en mouvement en temps réel sur la carte GPS
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </header>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-6">
          {/* ================= 1. LIVE GPS ROAD STAGE (PREVIEW) ================= */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className={`text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 ${
                isLight ? 'text-slate-600' : 'text-neutral-400'
              }`}>
                <Eye className="w-3.5 h-3.5 text-yellow-500" />
                <span>Prévisualisation en direct sur la route</span>
              </span>

              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/50 border border-emerald-800/60 px-2 py-0.5 rounded-full flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                Orientation: {previewHeading}°
              </span>
            </div>

            {/* Asphalt Simulation Stage */}
            <div className="relative h-48 w-full rounded-2xl overflow-hidden border border-slate-700/80 shadow-inner flex items-center justify-center bg-gradient-to-b from-slate-900 via-slate-800 to-slate-950">
              {/* Road markings */}
              <div className="absolute inset-0 flex flex-col justify-between py-3 pointer-events-none opacity-40">
                <div className="w-full border-t border-dashed border-white/40" />
                <div className="w-full border-t-2 border-yellow-400/50" />
                <div className="w-full border-t border-dashed border-white/40" />
              </div>

              {/* The Actual Real-Time Moving Vehicle Marker */}
              <div className="relative z-10">
                <TopDownCarMarker
                  heading={previewHeading}
                  driverName={currentDriver.name}
                  isLive={true}
                  config={config}
                  speedKmh={isSimulatingDriving ? 52 : 0}
                  interactive={false}
                />
              </div>

              {/* Quick Rotation & Test Controls Floating on Stage */}
              <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between gap-2 z-20">
                <div className="flex items-center gap-1.5 bg-black/75 backdrop-blur-md px-2 py-1 rounded-xl border border-white/10 text-xs">
                  <button
                    type="button"
                    onClick={() => setPreviewHeading((prev) => (prev - 45 + 360) % 360)}
                    title="Tourner à gauche (-45°)"
                    className="p-1 rounded-lg hover:bg-white/10 text-slate-200 active:scale-95 transition"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewHeading(0)}
                    title="Réinitialiser cap au Nord (0°)"
                    className="px-2 py-0.5 rounded-lg hover:bg-white/10 text-yellow-400 font-mono text-[11px] font-bold active:scale-95 transition"
                  >
                    0° Nord
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewHeading((prev) => (prev + 45) % 360)}
                    title="Tourner à droite (+45°)"
                    className="p-1 rounded-lg hover:bg-white/10 text-slate-200 active:scale-95 transition"
                  >
                    <RotateCw className="w-3.5 h-3.5" />
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => setIsSimulatingDriving(!isSimulatingDriving)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-lg backdrop-blur-md transition active:scale-95 ${
                    isSimulatingDriving
                      ? 'bg-rose-600 text-white border border-rose-500'
                      : 'bg-yellow-400 text-black border border-yellow-300 font-extrabold'
                  }`}
                >
                  {isSimulatingDriving ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                  <span>{isSimulatingDriving ? 'Arrêter test' : 'Tester virages'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* ================= 2. VEHICLE MODEL SELECTOR ================= */}
          <div className="space-y-3">
            <span className={`text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 ${
              isLight ? 'text-slate-600' : 'text-neutral-400'
            }`}>
              <Car className="w-3.5 h-3.5 text-yellow-500" />
              <span>Modèle de carrosserie</span>
            </span>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {vehicleModels.map((item) => {
                const isSelected = config.vehicleType === item.type;
                return (
                  <button
                    key={item.type}
                    type="button"
                    onClick={() => {
                      soundEffects.playClick();
                      setConfig((prev) => ({ ...prev, vehicleType: item.type }));
                    }}
                    className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all active:scale-95 relative overflow-hidden ${
                      isSelected
                        ? 'bg-yellow-400 text-black border-yellow-400 shadow-md ring-2 ring-yellow-400/40 font-bold'
                        : isLight
                        ? 'bg-slate-50 border-slate-200 text-slate-800 hover:bg-slate-100'
                        : 'bg-neutral-900 border-neutral-800 text-neutral-200 hover:bg-neutral-850 hover:border-neutral-700'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full mb-1">
                      <span className="text-xl">{item.icon}</span>
                      {isSelected && (
                        <span className="w-4 h-4 rounded-full bg-black text-yellow-400 flex items-center justify-center">
                          <Check className="w-2.5 h-2.5 stroke-[3]" />
                        </span>
                      )}
                    </div>
                    <div>
                      <p className="font-bold text-xs leading-tight">{item.title}</p>
                      <p className={`text-[10px] mt-0.5 line-clamp-1 ${
                        isSelected ? 'text-black/80' : isLight ? 'text-slate-500' : 'text-neutral-400'
                      }`}>
                        {item.subtitle}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* ================= 3. CHASSIS PAINT COLOR PALETTE ================= */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className={`text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 ${
                isLight ? 'text-slate-600' : 'text-neutral-400'
              }`}>
                <Palette className="w-3.5 h-3.5 text-yellow-500" />
                <span>Couleur de la carrosserie</span>
              </span>

              <span className="text-xs font-bold text-yellow-500">
                {COLOR_PALETTES[config.color]?.name || config.color}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {Object.entries(COLOR_PALETTES).map(([key, pal]) => {
                const isSelected = config.color === key;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => {
                      soundEffects.playClick();
                      setConfig((prev) => ({ ...prev, color: key }));
                    }}
                    className={`p-2.5 rounded-2xl border flex items-center gap-2.5 transition active:scale-95 ${
                      isSelected
                        ? 'border-yellow-400 bg-yellow-400/10 shadow-sm ring-2 ring-yellow-400/40'
                        : isLight
                        ? 'border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-800'
                        : 'border-neutral-800 bg-neutral-900 hover:bg-neutral-850 text-neutral-300'
                    }`}
                  >
                    <div
                      className="w-6 h-6 rounded-full border shadow-sm flex items-center justify-center flex-shrink-0"
                      style={{
                        backgroundColor: pal.body,
                        borderColor: pal.border,
                      }}
                    >
                      {isSelected && (
                        <Check
                          className={`w-3.5 h-3.5 stroke-[3] ${
                            key === 'white' ? 'text-black' : 'text-white'
                          }`}
                        />
                      )}
                    </div>
                    <span className="text-xs font-semibold truncate">{pal.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* ================= 4. HEADLIGHTS & LIGHT BEAMS ================= */}
          <div className={`p-4 rounded-3xl border space-y-3 ${
            isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900 border-neutral-800'
          }`}>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-bold text-xs flex items-center gap-1.5">
                  <Sun className="w-4 h-4 text-amber-400" />
                  <span>Phares LED & Faisceaux lumineux sur la route</span>
                </p>
                <p className={`text-[11px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                  Projette des faisceaux de lumière dynamiques devant la voiture
                </p>
              </div>

              <button
                type="button"
                onClick={() => setConfig((prev) => ({ ...prev, headlightsEnabled: !prev.headlightsEnabled }))}
                className={`w-12 h-7 rounded-full p-1 transition-colors duration-200 ${
                  config.headlightsEnabled ? 'bg-yellow-400' : isLight ? 'bg-slate-300' : 'bg-neutral-800'
                }`}
              >
                <div className={`w-5 h-5 rounded-full bg-black shadow transform transition duration-200 ${
                  config.headlightsEnabled ? 'translate-x-5' : 'translate-x-0 bg-white'
                }`} />
              </button>
            </div>

            {config.headlightsEnabled && (
              <div className="pt-2 border-t border-slate-200 dark:border-neutral-800 grid grid-cols-3 gap-2">
                {Object.entries(HEADLIGHT_COLORS).map(([key, hl]) => {
                  const isSelected = (config.headlightsColor || 'yellow') === key;
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setConfig((prev) => ({ ...prev, headlightsColor: key as any }))}
                      className={`py-2 px-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition active:scale-95 ${
                        isSelected
                          ? 'bg-yellow-400 text-black border-yellow-400 shadow-sm'
                          : isLight
                          ? 'bg-white border-slate-300 text-slate-700'
                          : 'bg-neutral-950 border-neutral-700 text-neutral-300'
                      }`}
                    >
                      <span
                        className="w-2.5 h-2.5 rounded-full border border-black/20"
                        style={{ backgroundColor: hl.light }}
                      />
                      <span className="truncate">{hl.label.split(' ')[0]}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* ================= 5. GPS PULSE HALO & SIZE SLIDER ================= */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Halo pulse style */}
            <div className={`p-4 rounded-3xl border space-y-2.5 ${
              isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900 border-neutral-800'
            }`}>
              <p className="font-bold text-xs flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-yellow-500" />
                <span>Onde radar GPS en temps réel</span>
              </p>
              <div className="grid grid-cols-2 gap-1.5">
                {haloOptions.map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setConfig((prev) => ({ ...prev, haloPulse: opt.id }))}
                    className={`py-2 px-2 rounded-xl text-[11px] font-bold border flex items-center gap-1.5 transition ${
                      config.haloPulse === opt.id
                        ? 'bg-yellow-400 text-black border-yellow-400 shadow-sm'
                        : isLight
                        ? 'bg-white border-slate-200 text-slate-700'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-300'
                    }`}
                  >
                    <span className={`w-2 h-2 rounded-full ${opt.color}`} />
                    <span className="truncate">{opt.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Pictogram scale size */}
            <div className={`p-4 rounded-3xl border space-y-2.5 ${
              isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900 border-neutral-800'
            }`}>
              <div className="flex items-center justify-between">
                <p className="font-bold text-xs flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-yellow-500" />
                  <span>Taille sur la carte</span>
                </p>
                <span className="text-xs font-mono font-bold text-yellow-500">{config.size}px</span>
              </div>

              <div className="flex items-center gap-2 pt-1">
                {[26, 30, 36].map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setConfig((prev) => ({ ...prev, size: s }))}
                    className={`flex-1 py-1.5 rounded-xl text-xs font-bold border transition ${
                      config.size === s
                        ? 'bg-yellow-400 text-black border-yellow-400 shadow-sm'
                        : isLight
                        ? 'bg-white border-slate-200 text-slate-700'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-300'
                    }`}
                  >
                    {s === 26 ? 'Compact' : s === 30 ? 'Standard' : 'Grand'}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* ================= 6. DRIVER TAG OPTIONS ================= */}
          <div className={`p-4 rounded-3xl border flex items-center justify-between ${
            isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900 border-neutral-800'
          }`}>
            <div>
              <p className="font-bold text-xs">Afficher l'étiquette chauffeur au-dessus</p>
              <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                Indicateur en direct avec le nom du chauffeur
              </p>
            </div>

            <button
              type="button"
              onClick={() => setConfig((prev) => ({ ...prev, showDriverTag: !prev.showDriverTag }))}
              className={`w-12 h-7 rounded-full p-1 transition-colors duration-200 ${
                config.showDriverTag ? 'bg-yellow-400' : isLight ? 'bg-slate-300' : 'bg-neutral-800'
              }`}
            >
              <div className={`w-5 h-5 rounded-full bg-black shadow transform transition duration-200 ${
                config.showDriverTag ? 'translate-x-5' : 'translate-x-0 bg-white'
              }`} />
            </button>
          </div>
        </div>

        {/* Footer Actions */}
        <footer className={`px-5 py-4 border-t flex items-center justify-between gap-3 flex-shrink-0 ${
          isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900 border-neutral-800'
        }`}>
          <button
            type="button"
            onClick={handleResetDefault}
            className={`px-4 py-3 rounded-2xl text-xs font-bold border transition active:scale-95 ${
              isLight
                ? 'bg-white border-slate-300 text-slate-700 hover:bg-slate-100'
                : 'bg-neutral-800 border-neutral-700 text-neutral-300 hover:bg-neutral-700'
            }`}
          >
            Réinitialiser défaut
          </button>

          <button
            type="button"
            onClick={handleApply}
            className={`flex-1 py-3 px-5 rounded-2xl font-black text-xs flex items-center justify-center gap-2 transition active:scale-95 shadow-lg ${
              saveSuccess
                ? 'bg-emerald-500 text-white'
                : 'bg-yellow-400 hover:bg-yellow-300 text-black shadow-yellow-400/20'
            }`}
          >
            {saveSuccess ? (
              <>
                <Check className="w-4 h-4 stroke-[3]" />
                <span>Enregistré & Appliqué !</span>
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 fill-current" />
                <span>Appliquer sur la carte en temps réel</span>
              </>
            )}
          </button>
        </footer>
      </div>
    </div>
  );
};
