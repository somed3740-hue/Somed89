import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Settings, 
  User, 
  Car, 
  Star, 
  ShieldCheck, 
  CheckCircle2, 
  Edit3, 
  Wallet, 
  Clock, 
  ChevronRight, 
  Power, 
  Repeat,
  Globe,
  Check,
  Sparkles,
  FileText,
  Bell,
  ScanFace,
  XCircle,
  AlertCircle,
  Trash2,
  FileSpreadsheet
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { formatEuro } from '../../utils/geo';
import { useTranslation, SUPPORTED_LANGUAGES, Language } from '../../utils/i18n';
import { soundEffects } from '../../utils/audio';
import { PictogramCustomizerModal } from '../Modals/PictogramCustomizerModal';
import { DeleteAccountModal } from '../Modals/DeleteAccountModal';
import { exportDriverRGPDToExcel } from '../../utils/rgpdExcelExport';
import { DriverDocumentsModal } from './DriverDocumentsModal';
import { DriverUploadDocModal } from './DriverUploadDocModal';
import { DriverFacialAuthModal } from './DriverFacialAuthModal';
import { DriverDocumentItem } from '../../types/vtc';

interface DriverProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenEditProfile: () => void;
  onOpenEarnings: () => void;
  onOpenActivity: () => void;
  onOpenSettings: () => void;
  onSwitchMode?: () => void;
}

export const DriverProfileModal: React.FC<DriverProfileModalProps> = ({
  isOpen,
  onClose,
  onOpenEditProfile,
  onOpenEarnings,
  onOpenActivity,
  onOpenSettings,
  onSwitchMode,
}) => {
  const isLight = vtcStore.isLightMode();
  const driver = vtcStore.getCurrentDriver();
  const [isPictogramModalOpen, setIsPictogramModalOpen] = useState(false);
  const [isDocumentsModalOpen, setIsDocumentsModalOpen] = useState(false);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isFacialModalOpen, setIsFacialModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [hasExportedExcel, setHasExportedExcel] = useState(false);
  const [selectedDocForUpload, setSelectedDocForUpload] = useState<DriverDocumentItem | null>(null);
  const { lang, t, setLanguage } = useTranslation();
  const documents = vtcStore.getDriverDocuments(driver.id);
  const facialData = vtcStore.getDriverFacialVerification(driver.id);
  const totalDocsCount = documents.length;
  const validDocsCount = documents.filter((d) => d.status === 'VALID').length;
  const isDossierComplete = totalDocsCount > 0 && validDocsCount === totalDocsCount;
  const progressPercent = totalDocsCount > 0 ? Math.round((validDocsCount / totalDocsCount) * 100) : 0;

  const handleSelectLanguage = (code: Language) => {
    soundEffects.playClick();
    setLanguage(code);

    const labels: Record<Language, string> = {
      fr: 'Français activé pour toute l’application',
      en: 'English activated across all interfaces',
      es: 'Español activado en todas las interfaces',
    };

    vtcStore.sendPushNotification({
      title: t('language'),
      body: labels[code],
      category: 'SYSTEM',
      badge: code.toUpperCase(),
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[1250] flex flex-col select-none animate-in fade-in duration-200">
      <div 
        className={`h-full w-full flex flex-col overflow-y-auto transition-colors ${
          isLight ? 'bg-slate-50 text-slate-900' : 'bg-black text-white'
        }`}
      >
        {/* Top Header */}
        <header className={`px-5 py-4 border-b flex items-center justify-between sticky top-0 backdrop-blur-md z-20 ${
          isLight ? 'border-slate-200 bg-white/95' : 'border-neutral-900 bg-black/95'
        }`}>
          <button
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="font-bold text-base">{t('driverProfile')}</h2>
          <button
            onClick={onOpenSettings}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <Settings className="w-5 h-5" />
          </button>
        </header>

        {/* Profile Details Container */}
        <div className="flex-1 max-w-lg mx-auto w-full p-5 space-y-5">
          {/* Driver Hero Card */}
          <div className={`p-6 rounded-3xl border flex flex-col items-center text-center shadow-xl relative overflow-hidden ${
            isLight ? 'bg-white border-slate-200 shadow-slate-200' : 'bg-neutral-950 border-neutral-800'
          }`}>
            <div className="relative mb-3">
              <div className="w-24 h-24 rounded-full border-2 border-yellow-400 p-0.5 overflow-hidden flex items-center justify-center shadow-lg bg-neutral-900">
                <img
                  src={driver.avatarUrl}
                  alt={driver.name}
                  className="w-full h-full object-cover rounded-full"
                />
              </div>
              <span className={`absolute bottom-0 right-0 w-6 h-6 rounded-full border-2 ${
                isLight ? 'border-white' : 'border-black'
              } flex items-center justify-center ${
                driver.isOnline ? 'bg-emerald-500 text-white' : 'bg-slate-500 text-slate-200'
              }`}>
                <Power className="w-3.5 h-3.5" />
              </span>
            </div>

            <div className="flex items-center gap-2">
              <h1 className="font-black text-xl tracking-tight">{driver.name}</h1>
              <span className="text-[10px] font-bold bg-yellow-400 text-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                VTC Pro
              </span>
            </div>

            <p className={`text-xs mt-0.5 font-medium ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
              {driver.phone} · {driver.email}
            </p>

            {/* 3 Driver Performance Stats */}
            <div className={`grid grid-cols-3 gap-2 w-full mt-5 p-3 rounded-2xl border text-center ${
              isLight ? 'bg-slate-100 border-slate-200' : 'bg-neutral-900 border-neutral-800'
            }`}>
              <div>
                <p className="text-base font-bold text-yellow-500 flex items-center justify-center gap-1">
                  <Star className="w-4 h-4 fill-yellow-400" />
                  <span>{driver.rating.toFixed(2)}</span>
                </p>
                <p className={`text-[11px] font-medium ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>{t('driverRating')}</p>
              </div>

              <div className={`border-x ${isLight ? 'border-slate-300' : 'border-neutral-800'}`}>
                <p className="text-base font-bold text-emerald-500">{driver.acceptanceRate}%</p>
                <p className={`text-[11px] font-medium ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>{t('driverAcceptanceRate')}</p>
              </div>

              <div>
                <p className="text-base font-bold">{driver.totalRides}</p>
                <p className={`text-[11px] font-medium ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>{t('tabTaxi')}</p>
              </div>
            </div>

            {/* Quick Action Buttons */}
            <div className="w-full mt-4 space-y-2">
              <button
                onClick={() => {
                  onClose();
                  onSwitchMode?.();
                }}
                className="w-full py-3 px-4 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-xs flex items-center justify-center gap-2 transition active:scale-95 shadow-md shadow-yellow-400/20"
              >
                <Repeat className="w-4 h-4 stroke-[2.5]" />
                <span>{t('switchInterface')}</span>
              </button>

              <button
                onClick={onOpenEditProfile}
                className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold border transition flex items-center justify-center gap-2 active:scale-95 ${
                  isLight 
                    ? 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-800' 
                    : 'bg-neutral-900 hover:bg-neutral-800 border-neutral-700 text-white'
                }`}
              >
                <Edit3 className="w-4 h-4 text-yellow-500" />
                <span>{t('editProfile')}</span>
              </button>
            </div>
          </div>

          {/* ================= SECTION LANGUE DE L'APPLICATION (Français, Anglais, Espagnol) ================= */}
          <div className={`p-5 rounded-3xl border space-y-3 ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
          }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-yellow-400/20 text-yellow-500 flex items-center justify-center">
                  <Globe className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm">{t('language')}</h3>
                  <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                    {t('languageSubtitle')}
                  </p>
                </div>
              </div>
              <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-yellow-400 text-black uppercase">
                {lang}
              </span>
            </div>

            {/* 3 Selectable Buttons: Français, English, Español */}
            <div className="grid grid-cols-3 gap-2 pt-1">
              {SUPPORTED_LANGUAGES.map((item) => {
                const isSelected = lang === item.code;
                return (
                  <button
                    key={item.code}
                    type="button"
                    onClick={() => handleSelectLanguage(item.code)}
                    className={`p-3 rounded-2xl border flex flex-col items-center justify-center gap-1 transition active:scale-95 ${
                      isSelected
                        ? 'bg-yellow-400 border-yellow-400 text-black font-extrabold shadow-md shadow-yellow-400/20 ring-2 ring-yellow-400/30'
                        : isLight 
                        ? 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100 hover:border-slate-300' 
                        : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:bg-neutral-900/80 hover:text-white'
                    }`}
                  >
                    <span className="text-xl">{item.flag}</span>
                    <span className="text-xs font-bold">{item.name}</span>
                    {isSelected && (
                      <span className="text-[9px] bg-black text-yellow-400 px-1.5 py-0.2 rounded-full font-black flex items-center gap-0.5">
                        <Check className="w-2.5 h-2.5" /> {t('active')}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Vehicle Information Card */}
          <div className={`p-5 rounded-3xl border space-y-3 ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
          }`}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm flex items-center gap-2">
                <Car className="w-4 h-4 text-yellow-500" />
                <span>{t('driverRegisteredVehicle')}</span>
              </h3>
              <span className="text-[10px] font-bold bg-emerald-500/20 text-emerald-500 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                {t('driverApproved')}
              </span>
            </div>

            <div className={`p-3.5 rounded-2xl border flex items-center justify-between ${
              isLight ? 'bg-slate-100 border-slate-200' : 'bg-neutral-900/60 border-neutral-800'
            }`}>
              <div>
                <p className="font-bold text-sm">
                  {driver.vehicle.brand} {driver.vehicle.model}
                </p>
                <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                  {driver.vehicle.color} · {driver.vehicle.year || 2019}
                </p>
              </div>

              <div className="text-right">
                <span className="font-mono font-black text-sm bg-yellow-400 text-black px-2.5 py-1 rounded-lg border border-black/20 shadow-sm">
                  {driver.vehicle.plate}
                </span>
                <p className={`text-[10px] font-bold uppercase mt-1 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                  {driver.vehicle.category}
                </p>
              </div>
            </div>

            {/* Service types chips */}
            {driver.serviceTypes && driver.serviceTypes.length > 0 && (
              <div className="pt-2">
                <p className={`text-[11px] font-semibold mb-2 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                  Services :
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {driver.serviceTypes.map((type) => (
                    <span 
                      key={type}
                      className={`text-[11px] px-2.5 py-1 rounded-lg font-medium border ${
                        isLight 
                          ? 'bg-slate-100 border-slate-300 text-slate-700' 
                          : 'bg-neutral-900 border-neutral-800 text-neutral-300'
                      }`}
                    >
                      ✓ {type}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Pictogram Customizer button */}
            <div className="pt-2 border-t border-slate-200 dark:border-neutral-900">
              <button
                type="button"
                onClick={() => setIsPictogramModalOpen(true)}
                className={`w-full py-2.5 px-3.5 rounded-2xl border flex items-center justify-between transition active:scale-95 ${
                  isLight 
                    ? 'bg-amber-50 hover:bg-amber-100/80 border-amber-300 text-amber-950' 
                    : 'bg-amber-950/20 hover:bg-amber-900/30 border-amber-500/40 text-yellow-400'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span className="text-xl">🚗</span>
                  <div className="text-left">
                    <p className="text-xs font-bold leading-tight">Personnaliser le pictogramme GPS</p>
                    <p className={`text-[10px] mt-0.5 ${isLight ? 'text-amber-800' : 'text-neutral-400'}`}>
                      Modèle, couleur, phares LED & faisceaux en direct
                    </p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-yellow-500" />
              </button>
            </div>
          </div>

          {/* Quick Access Menu Cards */}
          <div className={`rounded-3xl border divide-y overflow-hidden ${
            isLight 
              ? 'bg-white border-slate-200 divide-slate-100' 
              : 'bg-neutral-950 border-neutral-800 divide-neutral-900'
          }`}>
            {/* Earnings & Wallet */}
            <button
              onClick={onOpenEarnings}
              className={`w-full p-4 flex items-center justify-between transition group text-left ${
                isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
              }`}
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-500 flex items-center justify-center">
                  <Wallet className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-bold text-sm">{t('driverEarnings')}</p>
                  <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                    Solde : <strong className="text-emerald-500 font-bold">{formatEuro(driver.driverWalletBalance || 0)}</strong>
                  </p>
                </div>
              </div>
              <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
            </button>

            {/* Trip Activity */}
            <button
              onClick={onOpenActivity}
              className={`w-full p-4 flex items-center justify-between transition group text-left ${
                isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
              }`}
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-2xl bg-blue-500/20 text-blue-500 flex items-center justify-center">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-bold text-sm">{t('driverActivity')}</p>
                  <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                    {t('drawerActivity')}
                  </p>
                </div>
              </div>
              <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
            </button>

            {/* Switch mode */}
            <button
              onClick={() => {
                onClose();
                onSwitchMode?.();
              }}
              className={`w-full p-4 flex items-center justify-between transition group text-left ${
                isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
              }`}
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-2xl bg-yellow-400/20 text-yellow-500 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Repeat className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-bold text-sm">{t('switchInterface')}</p>
                    <span className="text-[10px] font-bold bg-yellow-400 text-black px-1.5 py-0.2 rounded uppercase">
                      {t('active')}
                    </span>
                  </div>
                  <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                    Passager, Chauffeur, Business
                  </p>
                </div>
              </div>
              <ChevronRight className={`w-4 h-4 group-hover:translate-x-0.5 transition-transform ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
            </button>
          </div>

          {/* ================= SECTION NOTIFICATIONS & VÉRIFICATION FACIALE (IMAGE 1: IMG_20261011_041829.jpg) ================= */}
          <div className={`rounded-3xl border divide-y overflow-hidden shadow-sm ${
            isLight 
              ? 'bg-white border-slate-200 divide-slate-100' 
              : 'bg-neutral-950 border-neutral-800 divide-neutral-900'
          }`}>
            {/* Notifications */}
            <button
              type="button"
              onClick={onOpenSettings}
              className={`w-full p-4 flex items-center justify-between transition group text-left ${
                isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
              }`}
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-yellow-500 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Bell className="w-5 h-5 stroke-[2.2]" />
                </div>
                <div>
                  <p className="font-bold text-sm">Notifications</p>
                  <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                    Configurer les alertes
                  </p>
                </div>
              </div>
              <ChevronRight className={`w-4 h-4 group-hover:translate-x-0.5 transition-transform ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
            </button>

            {/* Vérification faciale */}
            <button
              type="button"
              onClick={() => {
                soundEffects.playClick();
                setIsFacialModalOpen(true);
              }}
              className={`w-full p-4 flex items-center justify-between transition group text-left ${
                isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
              }`}
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-2xl bg-purple-500/20 text-purple-400 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <ScanFace className="w-5 h-5 stroke-[2.2]" />
                </div>
                <div>
                  <p className="font-bold text-sm">Vérification faciale</p>
                  <p className={`text-xs mt-0.5 ${
                    facialData.isVerified 
                      ? 'text-emerald-400 font-bold flex items-center gap-1' 
                      : isLight ? 'text-slate-500' : 'text-neutral-400'
                  }`}>
                    {facialData.isVerified ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 inline" />
                        Effectuée
                      </>
                    ) : (
                      'Non effectuée'
                    )}
                  </p>
                </div>
              </div>
              <ChevronRight className={`w-4 h-4 group-hover:translate-x-0.5 transition-transform ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
            </button>
          </div>

          {/* ================= SECTION CONFORMITÉ & DOCUMENTS PROFESSIONNELS ================= */}
          <div className={`p-5 rounded-3xl border space-y-4 shadow-sm ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
          }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center transition-colors ${
                  isDossierComplete ? 'bg-emerald-500/15 text-emerald-500' : 'bg-red-500/15 text-red-500'
                }`}>
                  <ShieldCheck className="w-4 h-4 stroke-[2.3]" />
                </div>
                <div>
                  <h3 className={`font-bold text-sm leading-tight ${
                    isDossierComplete ? 'text-emerald-500' : 'text-white'
                  }`}>
                    {t('driverCompliance')}
                  </h3>
                  <p className={`text-[11px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                    Réglementation et habilitation transport
                  </p>
                </div>
              </div>

              {isDossierComplete ? (
                <span className="text-[10px] font-black px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-500 border border-emerald-500/30 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  Dossier complet
                </span>
              ) : (
                <span className="text-[10px] font-black px-2.5 py-1 rounded-full bg-red-500/15 text-red-500 border border-red-500/30 flex items-center gap-1">
                  <XCircle className="w-3 h-3" />
                  Dossier incomplet ({validDocsCount}/{totalDocsCount})
                </span>
              )}
            </div>

            {/* BARRE DE PROGRESSION ADAPTATIVE (Selon dossier complet ou incomplet) */}
            <div className={`p-3.5 rounded-2xl border transition-all ${
              isDossierComplete
                ? isLight 
                  ? 'bg-emerald-50/60 border-emerald-200' 
                  : 'bg-emerald-950/20 border-emerald-900/50'
                : isLight
                  ? 'bg-red-50/60 border-red-200'
                  : 'bg-red-950/20 border-red-900/40'
            }`}>
              <div className="flex items-center justify-between text-xs font-bold mb-2">
                <span className={isDossierComplete ? 'text-emerald-500 font-extrabold' : 'text-red-400 font-extrabold'}>
                  Progression des documents
                </span>
                <span className={`font-mono text-xs ${isDossierComplete ? 'text-emerald-400 font-extrabold' : 'text-red-400 font-bold'}`}>
                  {validDocsCount} sur {totalDocsCount} ({progressPercent}%)
                </span>
              </div>
              <div className={`w-full h-2 rounded-full overflow-hidden ${
                isLight ? 'bg-slate-200' : 'bg-neutral-800'
              }`}>
                <div 
                  className={`h-full rounded-full transition-all duration-500 ${
                    isDossierComplete 
                      ? 'bg-emerald-500 shadow-sm shadow-emerald-500/50' 
                      : 'bg-gradient-to-r from-red-600 via-rose-500 to-amber-500'
                  }`}
                  style={{ width: `${Math.max(progressPercent, 4)}%` }}
                />
              </div>
            </div>

            {/* LISTE DES DOCUMENTS PROFESSIONNELS */}
            <div className={`rounded-2xl border divide-y overflow-hidden ${
              isLight ? 'bg-slate-50/70 border-slate-200 divide-slate-200/80' : 'bg-neutral-900/40 border-neutral-800 divide-neutral-800/80'
            }`}>
              {documents.slice(0, 5).map((doc) => {
                const isValid = doc.status === 'VALID';
                return (
                  <div
                    key={doc.id}
                    onClick={() => {
                      soundEffects.playClick();
                      setSelectedDocForUpload(doc);
                      setIsUploadModalOpen(true);
                    }}
                    className={`p-3.5 flex items-center justify-between cursor-pointer transition active:scale-[0.99] group ${
                      isLight ? 'hover:bg-slate-100/90' : 'hover:bg-neutral-800/60'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0 pr-2">
                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors ${
                        isValid ? 'bg-emerald-500/15 text-emerald-500' : 'bg-red-500/15 text-red-500'
                      }`}>
                        <FileText className="w-4 h-4 stroke-[2.2]" />
                      </div>
                      <div className="min-w-0">
                        <p className="font-bold text-xs sm:text-sm truncate leading-tight">{doc.title}</p>
                        <p className={`text-[10px] truncate mt-0.5 ${
                          !isValid ? 'text-red-400/90 font-medium' : isLight ? 'text-slate-500' : 'text-neutral-400'
                        }`}>
                          {doc.subtitle}
                        </p>
                      </div>
                    </div>

                    {/* UNIQUEMENT L'ICÔNE (pas de texte "Validé", rouge en cas de manque) */}
                    <div className="flex items-center gap-2 flex-shrink-0">
                      {isValid ? (
                        <div 
                          title="Document validé"
                          className="w-7 h-7 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-500 flex items-center justify-center shadow-sm"
                        >
                          <CheckCircle2 className="w-4 h-4 stroke-[2.5]" />
                        </div>
                      ) : (
                        <div 
                          title="Document manquant ou incomplet"
                          className="w-7 h-7 rounded-full bg-red-500/15 border border-red-500/30 text-red-500 flex items-center justify-center shadow-sm"
                        >
                          <XCircle className="w-4 h-4 stroke-[2.5]" />
                        </div>
                      )}
                      <ChevronRight className={`w-4 h-4 group-hover:translate-x-0.5 transition-transform ${
                        isLight ? 'text-slate-400' : 'text-neutral-500'
                      }`} />
                    </div>
                  </div>
                );
              })}
            </div>

            {!isDossierComplete && (
              <p className={`text-[11px] px-1 font-medium ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>
                📷 Touchez un document ci-dessus pour le prendre en photo ou le charger un par un.
              </p>
            )}

            {/* BUTTON GÉRER LES DOCUMENTS (IMAGE 1) */}
            <button
              type="button"
              onClick={() => {
                soundEffects.playClick();
                setIsDocumentsModalOpen(true);
              }}
              className="w-full py-3.5 px-4 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-xs flex items-center justify-between transition active:scale-95 shadow-md shadow-yellow-400/20 group"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-black text-yellow-400 flex items-center justify-center">
                  <FileText className="w-4 h-4 stroke-[2.3]" />
                </div>
                <div className="text-left">
                  <p className="font-black text-xs leading-none">Gérer les documents</p>
                  <p className="text-[10px] text-black/80 font-medium mt-0.5">
                    Ajouter des documents ou les prendre en photo
                  </p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 stroke-[2.5] group-hover:translate-x-0.5 transition-transform" />
            </button>
          </div>

          {/* ================= GESTION DU COMPTE CHAUFFEUR & RGPD (SANS MENTION ZONE DE DANGER) ================= */}
          <div className="space-y-2 pt-1 pb-6">
            <h3 className={`text-xs font-semibold ${isLight ? 'text-slate-500' : 'text-neutral-500'}`}>
              Données professionnelles & Compte
            </h3>
            <div className={`rounded-2xl border divide-y overflow-hidden ${
              isLight ? 'bg-white border-slate-200 divide-slate-100' : 'bg-neutral-950 border-neutral-900 divide-neutral-900'
            }`}>
              {/* Exporter RGPD en Excel */}
              <button
                type="button"
                onClick={() => {
                  soundEffects.playClick();
                  exportDriverRGPDToExcel(driver);
                  setHasExportedExcel(true);
                }}
                className={`w-full p-4 flex items-center justify-between transition group text-left ${
                  isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center flex-shrink-0">
                    <FileSpreadsheet className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-sm block">Exporter conformité RGPD (Excel)</span>
                    <span className={`text-[10px] ${isLight ? 'text-slate-400' : 'text-neutral-500'}`}>
                      {hasExportedExcel ? 'Classeur .xlsx téléchargé avec succès' : 'Télécharger vos données chauffeur sous tableur Excel'}
                    </span>
                  </div>
                </div>
                {hasExportedExcel ? (
                  <Check className="w-4 h-4 text-emerald-500" />
                ) : (
                  <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-neutral-500'} group-hover:translate-x-0.5 transition-transform`} />
                )}
              </button>

              {/* Supprimer le compte chauffeur */}
              <button
                type="button"
                onClick={() => {
                  soundEffects.playClick();
                  setIsDeleteModalOpen(true);
                }}
                className={`w-full p-4 flex items-center justify-between transition group text-left ${
                  isLight ? 'hover:bg-rose-50/50' : 'hover:bg-rose-950/10'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-9 h-9 rounded-xl bg-rose-500/10 text-rose-500 flex items-center justify-center flex-shrink-0">
                    <Trash2 className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-sm text-rose-500 block">Supprimer mon compte chauffeur</span>
                    <span className={`text-[10px] ${isLight ? 'text-slate-400' : 'text-neutral-500'}`}>
                      Révocation définitive du profil partenaire, documents et historique
                    </span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-rose-500/70 group-hover:translate-x-0.5 transition-transform" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <PictogramCustomizerModal
        isOpen={isPictogramModalOpen}
        onClose={() => setIsPictogramModalOpen(false)}
        driverId={driver.id}
      />

      <DriverDocumentsModal
        isOpen={isDocumentsModalOpen}
        onClose={() => setIsDocumentsModalOpen(false)}
      />

      <DriverUploadDocModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        documentItem={selectedDocForUpload}
      />

      <DriverFacialAuthModal
        isOpen={isFacialModalOpen}
        onClose={() => setIsFacialModalOpen(false)}
      />

      <DeleteAccountModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        userType="driver"
        onAccountDeleted={() => {
          setIsDeleteModalOpen(false);
          onClose();
        }}
      />
    </div>
  );
};
