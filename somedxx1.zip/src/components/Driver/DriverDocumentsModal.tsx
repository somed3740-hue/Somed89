import React, { useState } from 'react';
import { 
  ArrowLeft, 
  ShieldCheck, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  ChevronRight, 
  FileText, 
  Car, 
  CreditCard, 
  Calendar, 
  Upload, 
  Camera,
  Eye, 
  Sparkles,
  Plus,
  BadgeCheck,
  XCircle
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { DriverDocumentItem } from '../../types/vtc';
import { DriverUploadDocModal } from './DriverUploadDocModal';
import { soundEffects } from '../../utils/audio';

interface DriverDocumentsModalProps {
  isOpen: boolean;
  onClose: () => void;
  driverId?: string;
}

export const DriverDocumentsModal: React.FC<DriverDocumentsModalProps> = ({
  isOpen,
  onClose,
  driverId,
}) => {
  const isLight = vtcStore.isLightMode();
  const driver = driverId 
    ? vtcStore.getAllDrivers().find(d => d.id === driverId) || vtcStore.getCurrentDriver()
    : vtcStore.getCurrentDriver();
  const documents = vtcStore.getDriverDocuments(driver?.id);

  const [selectedDoc, setSelectedDoc] = useState<DriverDocumentItem | null>(null);
  const [initialMode, setInitialMode] = useState<'camera' | 'upload' | undefined>(undefined);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);

  const handleOpenDoc = (doc: DriverDocumentItem, mode?: 'camera' | 'upload') => {
    soundEffects.playClick();
    setSelectedDoc(doc);
    setInitialMode(mode);
    setIsUploadModalOpen(true);
  };

  const handleAddNewDoc = (mode?: 'camera' | 'upload') => {
    soundEffects.playClick();
    const newDocId = `doc-custom-${Date.now()}`;
    const newDoc: DriverDocumentItem = {
      id: newDocId,
      type: 'vtc_card',
      title: 'Nouveau document professionnel',
      subtitle: 'Ajouté par le chauffeur',
      status: 'PENDING',
      isMandatory: false,
      requiredSides: 'SINGLE',
      lastUpdated: 'À l’instant'
    };
    setSelectedDoc(newDoc);
    setInitialMode(mode);
    setIsUploadModalOpen(true);
  };

  const validDocsCount = documents.filter(d => d.status === 'VALID').length;
  const totalDocsCount = documents.length;
  const isDossierComplete = totalDocsCount > 0 && validDocsCount === totalDocsCount;
  const progressPercent = totalDocsCount > 0 ? Math.round((validDocsCount / totalDocsCount) * 100) : 0;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[1300] flex flex-col select-none animate-in fade-in duration-200">
      <div 
        className={`h-full w-full flex flex-col overflow-y-auto transition-colors ${
          isLight ? 'bg-slate-50 text-slate-900' : 'bg-black text-white'
        }`}
      >
        {/* Header */}
        <header className={`px-5 py-4 border-b flex items-center justify-between sticky top-0 backdrop-blur-md z-20 ${
          isLight ? 'border-slate-200 bg-white/95' : 'border-neutral-900 bg-black/95'
        }`}>
          <button
            type="button"
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="text-center">
            <h1 className="font-extrabold text-base">Documents professionnels</h1>
            <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
              Conformité & habilitation transport
            </p>
          </div>
          <div className={`w-9 h-9 rounded-full flex items-center justify-center border transition-colors ${
            isDossierComplete
              ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20'
              : 'bg-red-500/10 text-red-500 border-red-500/20'
          }`}>
            <ShieldCheck className="w-5 h-5" />
          </div>
        </header>

        {/* Container */}
        <div className="flex-1 max-w-lg mx-auto w-full p-5 space-y-5">
          {/* Status Overview Card */}
          <div className={`p-5 rounded-3xl border relative overflow-hidden shadow-sm transition-all ${
            isDossierComplete
              ? isLight ? 'bg-white border-emerald-200' : 'bg-neutral-950 border-emerald-900/40'
              : isLight ? 'bg-white border-red-200' : 'bg-neutral-950 border-red-900/40'
          }`}>
            <div className="flex items-start justify-between">
              <div>
                {isDossierComplete ? (
                  <span className="text-[10px] font-black uppercase tracking-wider text-emerald-500 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-0.5 rounded-full inline-flex items-center gap-1 mb-1.5">
                    <CheckCircle2 className="w-3 h-3" />
                    Dossier complet & conforme
                  </span>
                ) : (
                  <span className="text-[10px] font-black uppercase tracking-wider text-red-500 bg-red-500/10 border border-red-500/20 px-2.5 py-0.5 rounded-full inline-flex items-center gap-1 mb-1.5">
                    <XCircle className="w-3 h-3" />
                    Dossier incomplet ({validDocsCount}/{totalDocsCount})
                  </span>
                )}
                <h2 className="text-lg font-black tracking-tight">Statut de vos pièces justificatives</h2>
                <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                  {validDocsCount} sur {totalDocsCount} documents valides ({progressPercent}%)
                </p>
              </div>

              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-sm transition-colors ${
                isDossierComplete
                  ? 'bg-emerald-500/20 text-emerald-500 border border-emerald-500/30'
                  : 'bg-red-500/20 text-red-500 border border-red-500/30'
              }`}>
                {progressPercent}%
              </div>
            </div>

            {/* Progress Bar Adaptative */}
            <div className={`w-full h-2 rounded-full mt-4 overflow-hidden ${
              isLight ? 'bg-slate-200' : 'bg-neutral-900'
            }`}>
              <div 
                className={`h-full rounded-full transition-all duration-500 ${
                  isDossierComplete 
                    ? 'bg-emerald-500 shadow-sm shadow-emerald-500/50' 
                    : 'bg-gradient-to-r from-red-600 via-rose-500 to-amber-500'
                }`}
                style={{ width: `${Math.max(progressPercent, 4)}%` }}
              />
            </div>

            <p className={`text-[11px] mt-3 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
              {isDossierComplete 
                ? 'Tous vos documents sont validés. Votre compte chauffeur est 100% conforme.' 
                : 'Attention : le dossier est incomplet. Veuillez photographier ou importer les pièces requises affichées en rouge.'}
            </p>
          </div>

          {/* QUICK ACTION BUTTONS: PRENDRE PHOTO & CHARGER DOCUMENT */}
          <div className="space-y-2">
            <p className={`text-[11px] font-bold uppercase tracking-wider px-1 ${
              isLight ? 'text-slate-500' : 'text-neutral-400'
            }`}>
              Actions rapides :
            </p>
            <div className="grid grid-cols-2 gap-3">
              {/* Button 1: Prendre en photo */}
              <button
                type="button"
                onClick={() => handleAddNewDoc('camera')}
                className="p-4 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold flex items-center gap-3 transition active:scale-95 shadow-md shadow-yellow-400/20 group text-left"
              >
                <div className="w-10 h-10 rounded-xl bg-black text-yellow-400 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                  <Camera className="w-5 h-5 stroke-[2.3]" />
                </div>
                <div>
                  <p className="text-xs font-black leading-tight">Prendre photo</p>
                  <p className="text-[10px] text-black/80 font-medium mt-0.5">Appareil photo</p>
                </div>
              </button>

              {/* Button 2: Charger un document */}
              <button
                type="button"
                onClick={() => handleAddNewDoc('upload')}
                className={`p-4 rounded-2xl border font-extrabold flex items-center gap-3 transition active:scale-95 text-left ${
                  isLight 
                    ? 'bg-white hover:bg-slate-100 border-slate-200 text-slate-800' 
                    : 'bg-neutral-900 hover:bg-neutral-800 border-neutral-700 text-white'
                }`}
              >
                <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center flex-shrink-0">
                  <Upload className="w-5 h-5 stroke-[2.3]" />
                </div>
                <div>
                  <p className="text-xs font-black leading-tight">Charger fichier</p>
                  <p className={`text-[10px] font-medium mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>PDF, JPG, PNG</p>
                </div>
              </button>
            </div>
          </div>

          {/* DOCUMENTS LIST */}
          <div className="space-y-3">
            <div className="flex items-center justify-between px-1">
              <h3 className={`text-xs font-bold uppercase tracking-wider ${
                isLight ? 'text-slate-500' : 'text-neutral-400'
              }`}>
                Liste des pièces justificatives :
              </h3>
              <button
                type="button"
                onClick={() => handleAddNewDoc()}
                className="text-xs font-bold text-yellow-500 hover:text-yellow-400 flex items-center gap-1 transition"
              >
                <Plus className="w-3.5 h-3.5" />
                Ajouter
              </button>
            </div>

            <div className="space-y-2.5">
              {documents.map((doc) => {
                const isValid = doc.status === 'VALID';

                return (
                  <div
                    key={doc.id}
                    onClick={() => handleOpenDoc(doc)}
                    className={`p-4 rounded-2xl border transition active:scale-[0.99] cursor-pointer group flex items-center justify-between ${
                      isLight 
                        ? 'bg-white hover:bg-slate-50 border-slate-200' 
                        : 'bg-neutral-950 hover:bg-neutral-900/80 border-neutral-800'
                    }`}
                  >
                    <div className="flex items-center gap-3.5 flex-1 min-w-0 pr-3">
                      <div className={`w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0 transition-colors ${
                        isValid 
                          ? 'bg-emerald-500/15 text-emerald-500' 
                          : 'bg-red-500/15 text-red-500'
                      }`}>
                        <FileText className="w-5 h-5" />
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <p className="font-bold text-xs sm:text-sm truncate">{doc.title}</p>
                          {doc.isMandatory && (
                            <span className="text-[9px] font-black uppercase text-yellow-500">
                              Requis
                            </span>
                          )}
                        </div>

                        <p className={`text-[11px] truncate mt-0.5 ${
                          !isValid ? 'text-red-400 font-medium' : isLight ? 'text-slate-500' : 'text-neutral-400'
                        }`}>
                          {doc.subtitle}
                        </p>

                        <div className="flex items-center gap-2 mt-1">
                          {doc.expiryDate && (
                            <span className={`text-[10px] font-mono ${isLight ? 'text-slate-500' : 'text-neutral-500'}`}>
                              Exp : {doc.expiryDate}
                            </span>
                          )}
                          {doc.referenceNumber && (
                            <span className={`text-[10px] font-mono ${isLight ? 'text-slate-500' : 'text-neutral-500'}`}>
                              · {doc.referenceNumber}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 flex-shrink-0">
                      {isValid ? (
                        <div 
                          title="Document validé"
                          className="w-7 h-7 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-500 flex items-center justify-center shadow-sm"
                        >
                          <CheckCircle2 className="w-4 h-4 stroke-[2.5]" />
                        </div>
                      ) : (
                        <div 
                          title="Document manquant ou incomplet"
                          className="w-7 h-7 rounded-full bg-red-500/15 border border-red-500/30 text-red-500 flex items-center justify-center shadow-sm"
                        >
                          <XCircle className="w-4 h-4 stroke-[2.5]" />
                        </div>
                      )}
                      <ChevronRight className={`w-4 h-4 group-hover:translate-x-0.5 transition-transform ${
                        isLight ? 'text-slate-400' : 'text-neutral-500'
                      }`} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Upload & Photo Modal */}
      <DriverUploadDocModal
        isOpen={isUploadModalOpen}
        onClose={() => {
          setIsUploadModalOpen(false);
          setInitialMode(undefined);
        }}
        documentItem={selectedDoc}
        initialMode={initialMode}
      />
    </div>
  );
};
