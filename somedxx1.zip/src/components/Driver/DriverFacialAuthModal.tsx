import React, { useState, useRef, useEffect } from 'react';
import { 
  ArrowLeft, 
  Camera, 
  ShieldCheck, 
  CheckCircle2, 
  RefreshCw,
  ScanFace,
  Check,
  X
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { soundEffects } from '../../utils/audio';

interface DriverFacialAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export const DriverFacialAuthModal: React.FC<DriverFacialAuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const driver = vtcStore.getCurrentDriver();
  const facialData = vtcStore.getDriverFacialVerification(driver?.id || 'drv-1');

  // views: 'landing' (Image 2), 'camera' (Image 3), 'preview' (Confirmation & Save)
  const [view, setView] = useState<'landing' | 'camera' | 'preview'>(
    facialData.isVerified ? 'landing' : 'landing'
  );
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [hasCameraAccess, setHasCameraAccess] = useState<boolean | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Stop camera helper
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
  };

  // Clean up stream on unmount or when closed
  useEffect(() => {
    if (!isOpen) {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen]);

  // Start live selfie camera
  const startCamera = async () => {
    stopCamera();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'user',
          width: { ideal: 720 },
          height: { ideal: 960 }
        }
      });
      streamRef.current = stream;
      setHasCameraAccess(true);
      setView('camera');
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(console.error);
        }
      }, 100);
    } catch {
      console.warn('getUserMedia denied or unavailable, opening native camera picker');
      setHasCameraAccess(false);
      setView('camera');
      // Trigger native mobile front camera capture
      cameraInputRef.current?.click();
    }
  };

  // Handle native mobile front camera upload
  const handleNativeCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setCapturedPhoto(event.target?.result as string);
        setView('preview');
        soundEffects.playClick();
      };
      reader.readAsDataURL(file);
    }
  };

  // Capture snapshot from live video element
  const takeSnapshot = () => {
    soundEffects.playClick();
    if (videoRef.current && streamRef.current) {
      try {
        const video = videoRef.current;
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth || 640;
        canvas.height = video.videoHeight || 800;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          // Mirror horizontal flip for natural selfie
          ctx.translate(canvas.width, 0);
          ctx.scale(-1, 1);
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
          setCapturedPhoto(dataUrl);
          stopCamera();
          setView('preview');
          return;
        }
      } catch (err) {
        console.error('Error snapshotting live video:', err);
      }
    }
    // Fallback if live stream wasn't capturing
    cameraInputRef.current?.click();
  };

  // Save the facial verification selfie
  const handleSaveVerification = () => {
    if (!capturedPhoto) return;
    setIsSaving(true);
    soundEffects.playClick();

    setTimeout(() => {
      const nowStr = new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
      vtcStore.updateDriverFacialVerification(driver.id, {
        isVerified: true,
        status: 'VERIFIED',
        selfieUrl: capturedPhoto,
        verifiedAt: `Aujourd’hui à ${nowStr}`,
        confidenceScore: 99.8,
        referenceId: `BIO-FR-${Math.floor(100000 + Math.random() * 900000)}`
      });

      soundEffects.playSuccessSound();
      setIsSaving(false);
      stopCamera();
      onSuccess?.();
      onClose();
    }, 500);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[1450] flex flex-col bg-black text-white select-none animate-in fade-in duration-200">
      {/* Hidden input for native camera fallback */}
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="user"
        className="hidden"
        onChange={handleNativeCapture}
      />

      {/* ======================================================== */}
      {/* 1. LANDING VIEW (Image 2: Screenshot_20261001-193336.jpg) */}
      {/* ======================================================== */}
      {view === 'landing' && (
        <div className="flex-1 flex flex-col justify-between max-w-md mx-auto w-full p-5">
          {/* Header */}
          <header className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={() => {
                stopCamera();
                onClose();
              }}
              className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-neutral-900 transition active:scale-95"
            >
              <ArrowLeft className="w-6 h-6 text-white" />
            </button>
            <h1 className="font-extrabold text-base text-white">Vérification faciale</h1>
            <div className="w-10 h-10 flex items-center justify-center">
              <Camera className="w-6 h-6 text-yellow-400" />
            </div>
          </header>

          {/* Center content */}
          <div className="flex-1 flex flex-col items-center justify-center text-center px-4 space-y-4">
            {facialData.isVerified ? (
              <>
                <div className="relative">
                  <div className="w-28 h-28 rounded-full overflow-hidden border-4 border-emerald-500 shadow-2xl shadow-emerald-500/20 bg-neutral-900">
                    <img
                      src={facialData.selfieUrl || driver.avatarUrl}
                      alt={driver.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-emerald-500 text-black flex items-center justify-center border-2 border-black">
                    <Check className="w-5 h-5 stroke-[3]" />
                  </div>
                </div>

                <div className="space-y-1.5 pt-2">
                  <h2 className="text-xl font-black text-white">Vérification effectuée</h2>
                  <p className="text-sm text-neutral-400 max-w-xs leading-relaxed">
                    Votre identité est certifiée avec succès. Vous pouvez mettre à jour votre photo à tout moment.
                  </p>
                  {facialData.verifiedAt && (
                    <p className="text-xs font-mono text-emerald-400 pt-1">
                      {facialData.verifiedAt} · Réf {facialData.referenceId || 'BIO-FR-88914'}
                    </p>
                  )}
                </div>
              </>
            ) : (
              <>
                <div className="w-24 h-24 rounded-full flex items-center justify-center text-neutral-600">
                  <ShieldCheck className="w-20 h-20 stroke-[1.2]" />
                </div>

                <div className="space-y-1.5">
                  <h2 className="text-xl font-bold text-white">Aucune vérification</h2>
                  <p className="text-sm text-neutral-400 max-w-xs leading-relaxed">
                    Vous n’avez pas encore effectué de vérification faciale. Démarrez votre première vérification.
                  </p>
                </div>
              </>
            )}
          </div>

          {/* Bottom Button */}
          <div className="pb-4">
            <button
              type="button"
              onClick={startCamera}
              className="w-full py-4 px-6 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-sm flex items-center justify-center gap-2.5 transition active:scale-95 shadow-lg shadow-yellow-400/20"
            >
              <Camera className="w-5 h-5 stroke-[2.3]" />
              {facialData.isVerified ? 'Reprendre la vérification' : 'Démarrer la vérification'}
            </button>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 2. CAMERA VIEW (Image 3: Screenshot_20261001-193342.jpg) */}
      {/* ======================================================== */}
      {view === 'camera' && (
        <div className="flex-1 flex flex-col justify-between max-w-md mx-auto w-full p-5">
          {/* Header */}
          <header className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={() => {
                stopCamera();
                setView('landing');
              }}
              className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-neutral-900 transition active:scale-95"
            >
              <ArrowLeft className="w-6 h-6 text-white" />
            </button>
            <h1 className="font-extrabold text-base text-white">Vérification faciale</h1>
            <div className="w-10 h-10" />
          </header>

          {/* Oval Viewfinder */}
          <div className="flex-1 flex items-center justify-center py-4">
            <div className="relative w-[280px] h-[370px] rounded-[50%] border-2 border-white overflow-hidden bg-neutral-950 flex items-center justify-center shadow-2xl">
              {/* Live Video Feed */}
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover scale-x-[-1]"
              />

              {/* Placeholder icon if live stream hasn't started */}
              {(!streamRef.current || hasCameraAccess === false) && (
                <div 
                  onClick={() => cameraInputRef.current?.click()}
                  className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 cursor-pointer p-4 text-center"
                >
                  <div className="w-16 h-16 rounded-2xl bg-neutral-900 border border-neutral-700 flex items-center justify-center mb-3 text-neutral-300">
                    <Camera className="w-8 h-8 stroke-[1.8]" />
                  </div>
                  <p className="text-xs text-neutral-300 font-medium">
                    Appuyez sur le bouton pour capturer
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Bottom Information & Take Photo Button */}
          <div className="space-y-5 pb-4 text-center">
            <div className="space-y-1">
              <h3 className="font-extrabold text-sm text-white">
                Centrez votre visage dans l’ovale
              </h3>
              <p className="text-xs text-neutral-400 max-w-xs mx-auto leading-relaxed">
                Assurez-vous d’être dans un endroit bien éclairé et sans obstructions sur votre visage.
              </p>
            </div>

            <button
              type="button"
              onClick={takeSnapshot}
              className="w-full py-4 px-6 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-sm flex items-center justify-center gap-2.5 transition active:scale-95 shadow-lg shadow-yellow-400/20"
            >
              <Camera className="w-5 h-5 stroke-[2.3]" />
              Prendre la photo
            </button>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 3. PREVIEW & SAVE VIEW (Simple, concis, efficace)       */}
      {/* ======================================================== */}
      {view === 'preview' && (
        <div className="flex-1 flex flex-col justify-between max-w-md mx-auto w-full p-5">
          {/* Header */}
          <header className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={() => startCamera()}
              className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-neutral-900 transition active:scale-95"
            >
              <ArrowLeft className="w-6 h-6 text-white" />
            </button>
            <h1 className="font-extrabold text-base text-white">Confirmer la photo</h1>
            <div className="w-10 h-10" />
          </header>

          {/* Oval Preview of the Captured Photo */}
          <div className="flex-1 flex items-center justify-center py-4">
            <div className="relative w-[280px] h-[370px] rounded-[50%] border-4 border-yellow-400 overflow-hidden bg-neutral-950 flex items-center justify-center shadow-2xl shadow-yellow-400/20">
              {capturedPhoto && (
                <img
                  src={capturedPhoto}
                  alt="Selfie"
                  className="w-full h-full object-cover"
                />
              )}
              <div className="absolute top-4 right-6 bg-emerald-500 text-black p-1.5 rounded-full shadow-lg">
                <Check className="w-4 h-4 stroke-[3]" />
              </div>
            </div>
          </div>

          {/* Bottom Confirmation & Action Buttons */}
          <div className="space-y-4 pb-4 text-center">
            <div className="space-y-1">
              <h3 className="font-extrabold text-sm text-white">
                Photo capturée avec succès
              </h3>
              <p className="text-xs text-neutral-400 max-w-xs mx-auto leading-relaxed">
                Vérifiez la netteté de votre visage avant d’enregistrer votre vérification.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => startCamera()}
                className="py-4 px-4 rounded-2xl bg-neutral-900 hover:bg-neutral-800 text-white font-extrabold text-xs flex items-center justify-center gap-2 transition active:scale-95 border border-neutral-800"
              >
                <RefreshCw className="w-4 h-4" />
                Reprendre
              </button>

              <button
                type="button"
                disabled={isSaving}
                onClick={handleSaveVerification}
                className="py-4 px-4 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-xs flex items-center justify-center gap-2 transition active:scale-95 shadow-lg shadow-yellow-400/20 disabled:opacity-50"
              >
                {isSaving ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Enregistrement...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4 stroke-[2.3]" />
                    Enregistrer
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
