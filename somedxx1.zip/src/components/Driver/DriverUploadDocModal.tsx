import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  Camera, 
  Upload, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  Eye, 
  Trash2, 
  ShieldCheck, 
  Clock, 
  Sparkles,
  RefreshCw,
  Maximize2,
  XCircle
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { DriverDocumentItem } from '../../types/vtc';
import { soundEffects } from '../../utils/audio';

interface DriverUploadDocModalProps {
  isOpen: boolean;
  onClose: () => void;
  documentItem: DriverDocumentItem | null;
  initialMode?: 'camera' | 'upload';
  onSuccess?: () => void;
  driverId?: string;
}

export const DriverUploadDocModal: React.FC<DriverUploadDocModalProps> = ({
  isOpen,
  onClose,
  documentItem,
  initialMode,
  onSuccess,
  driverId,
}) => {
  const isLight = vtcStore.isLightMode();
  const driver = driverId 
    ? vtcStore.getAllDrivers().find(d => d.id === driverId) || vtcStore.getCurrentDriver()
    : vtcStore.getCurrentDriver();

  const [previewUrl, setPreviewUrl] = useState<string | null>(documentItem?.fileUrl || null);
  const [fileName, setFileName] = useState<string>(documentItem?.fileName || `${documentItem?.type || 'doc'}_doc.jpg`);
  const [fileType, setFileType] = useState<'image' | 'pdf'>(documentItem?.fileType || 'image');
  const [referenceNumber, setReferenceNumber] = useState<string>(documentItem?.referenceNumber || '');
  const [expiryDate, setExpiryDate] = useState<string>(documentItem?.expiryDate || '');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showLiveCamera, setShowLiveCamera] = useState(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Sync state when documentItem changes
  useEffect(() => {
    if (documentItem) {
      setPreviewUrl(documentItem.fileUrl || null);
      setFileName(documentItem.fileName || `${documentItem.type}_doc.jpg`);
      setFileType(documentItem.fileType || 'image');
      setReferenceNumber(documentItem.referenceNumber || '');
      setExpiryDate(documentItem.expiryDate || '');
      setShowLiveCamera(false);
    }
  }, [documentItem]);

  // Handle initialMode when opening
  useEffect(() => {
    if (isOpen && initialMode === 'camera') {
      startLiveCamera();
    } else if (isOpen && initialMode === 'upload') {
      setTimeout(() => fileInputRef.current?.click(), 100);
    }
  }, [isOpen, initialMode]);

  // Handle file selected from file picker or camera capture
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
      if (file.type.includes('pdf')) {
        setFileType('pdf');
      } else {
        setFileType('image');
      }

      const reader = new FileReader();
      reader.onload = (event) => {
        setPreviewUrl(event.target?.result as string);
        soundEffects.playClick();
      };
      reader.readAsDataURL(file);
    }
  };

  // Start live webcam for desktop/browser snapshot
  const startLiveCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } } 
      });
      setCameraStream(stream);
      setShowLiveCamera(true);
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(console.error);
        }
      }, 100);
    } catch {
      // If live camera is not permitted or unavailable, trigger the native file camera input
      cameraInputRef.current?.click();
    }
  };

  const stopLiveCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
    }
    setShowLiveCamera(false);
  };

  // Capture snapshot from live video
  const capturePhotoFromLiveCamera = () => {
    if (!documentItem) return;
    if (videoRef.current) {
      const video = videoRef.current;
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
        setPreviewUrl(dataUrl);
        setFileType('image');
        setFileName(`${documentItem.type}_photo_${Date.now()}.jpg`);
        soundEffects.playClick();
      }
    }
    stopLiveCamera();
  };

  // Handle saving and submitting the document
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!documentItem) return;
    setIsSubmitting(true);
    soundEffects.playClick();

    setTimeout(() => {
      vtcStore.updateDriverDocument(driver.id, documentItem.id, {
        status: 'VALID',
        fileUrl: previewUrl || documentItem.fileUrl,
        fileName: fileName,
        fileType: fileType,
        referenceNumber: referenceNumber || documentItem.referenceNumber,
        expiryDate: expiryDate || documentItem.expiryDate,
        lastUpdated: 'À l’instant'
      });

      setIsSubmitting(false);
      onSuccess?.();
      onClose();
    }, 700);
  };

  const handleMarkMissing = () => {
    if (!documentItem) return;
    setIsSubmitting(true);
    soundEffects.playClick();
    setTimeout(() => {
      vtcStore.updateDriverDocument(driver.id, documentItem.id, {
        status: 'ACTION_REQUIRED',
        fileUrl: undefined,
        fileName: undefined,
        lastUpdated: 'Non fourni / Manquant'
      });
      setIsSubmitting(false);
      onSuccess?.();
      onClose();
    }, 400);
  };

  // Stop camera if modal closes
  useEffect(() => {
    if (!isOpen) {
      stopLiveCamera();
    }
  }, [isOpen]);

  if (!isOpen || !documentItem) return null;

  return (
    <div className="fixed inset-0 z-[1400] flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-md p-0 sm:p-4 select-none animate-in fade-in duration-200">
      {/* Hidden file inputs */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*,application/pdf"
        className="hidden"
        onChange={handleFileChange}
      />
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={handleFileChange}
      />

      <div 
        className={`w-full max-w-lg rounded-t-3xl sm:rounded-3xl border shadow-2xl flex flex-col max-h-[92vh] overflow-hidden transition-all ${
          isLight 
            ? 'bg-white border-slate-200 text-slate-900 shadow-slate-300/50' 
            : 'bg-neutral-950 border-neutral-800 text-white'
        }`}
      >
        {/* Modal Header */}
        <header className={`px-5 py-4 border-b flex items-center justify-between flex-shrink-0 ${
          isLight ? 'border-slate-200 bg-slate-50' : 'border-neutral-900 bg-black'
        }`}>
          <div>
            <span className="text-[10px] font-black tracking-wider uppercase text-yellow-500 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              Conformité VTC Officielle
            </span>
            <h2 className="text-base font-extrabold line-clamp-1">{documentItem.title}</h2>
          </div>
          <button
            type="button"
            onClick={() => {
              stopLiveCamera();
              onClose();
            }}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </header>

        {/* Live Camera View Overlay if active */}
        {showLiveCamera ? (
          <div className="p-5 flex flex-col items-center justify-center bg-black text-white space-y-4">
            <div className="relative w-full aspect-[4/3] rounded-2xl overflow-hidden bg-neutral-900 border-2 border-yellow-400/80 shadow-lg">
              <video 
                ref={videoRef} 
                autoPlay 
                playsInline 
                muted 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-4 border border-dashed border-white/60 rounded-xl pointer-events-none flex items-center justify-center">
                <span className="text-xs bg-black/60 px-2.5 py-1 rounded-full text-white backdrop-blur">
                  Cadrez le document dans le rectangle
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3 w-full">
              <button
                type="button"
                onClick={stopLiveCamera}
                className="flex-1 py-3 px-4 rounded-xl bg-neutral-800 text-neutral-300 text-xs font-bold hover:bg-neutral-700 transition"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={capturePhotoFromLiveCamera}
                className="flex-1 py-3 px-4 rounded-xl bg-yellow-400 text-black font-extrabold text-xs hover:bg-yellow-300 transition flex items-center justify-center gap-2 shadow-lg shadow-yellow-400/20"
              >
                <Camera className="w-4 h-4" />
                Prendre la photo
              </button>
            </div>
          </div>
        ) : (
          /* Main Content */
          <div className="p-5 space-y-5 overflow-y-auto flex-1">
            {/* Guide Instructions Card */}
            <div className={`p-4 rounded-2xl border text-xs space-y-2 ${
              isLight 
                ? 'bg-amber-50/70 border-amber-200 text-amber-950' 
                : 'bg-yellow-950/20 border-yellow-500/30 text-yellow-200'
            }`}>
              <div className="flex items-center gap-2 font-bold">
                <Sparkles className="w-4 h-4 text-yellow-500 flex-shrink-0" />
                <span>Instructions de numérisation</span>
              </div>
              <ul className="space-y-1 text-[11px] opacity-90 pl-1">
                <li>• Les 4 coins du document doivent être entièrement visibles.</li>
                <li>• Veillez à une netteté irréprochable sans reflets ni ombres.</li>
                <li>• Formats acceptés : Photos (JPG, PNG) et documents PDF.</li>
              </ul>
            </div>

            {/* Document Preview / Current File */}
            <div className={`p-4 rounded-2xl border space-y-3 ${
              isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/60 border-neutral-800'
            }`}>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-yellow-500" />
                  Aperçu du document
                </span>
                <span className={`text-[10px] font-black px-2 py-0.5 rounded-full flex items-center gap-1 ${
                  previewUrl 
                    ? 'bg-emerald-500/15 text-emerald-500 border border-emerald-500/30' 
                    : 'bg-amber-500/15 text-amber-500 border border-amber-500/30'
                }`}>
                  <CheckCircle2 className="w-3 h-3" />
                  {previewUrl ? 'Fichier prêt' : 'Aucun fichier'}
                </span>
              </div>

              {previewUrl ? (
                <div className="relative rounded-xl overflow-hidden border border-neutral-700 bg-neutral-950 group">
                  {fileType === 'pdf' ? (
                    <div className="p-8 flex flex-col items-center justify-center text-center space-y-2 bg-gradient-to-b from-neutral-900 to-neutral-950">
                      <div className="w-14 h-14 rounded-2xl bg-red-500/20 text-red-400 flex items-center justify-center font-black text-sm">
                        PDF
                      </div>
                      <p className="text-xs font-bold text-white max-w-[200px] truncate">{fileName}</p>
                      <span className="text-[10px] text-neutral-400">Document PDF certifié</span>
                    </div>
                  ) : (
                    <div className="max-h-48 w-full overflow-hidden flex items-center justify-center bg-black">
                      <img
                        src={previewUrl}
                        alt={documentItem.title}
                        className="w-full max-h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  )}

                  <div className="p-2.5 bg-neutral-950/90 border-t border-neutral-800 flex items-center justify-between text-[11px]">
                    <span className="text-neutral-400 font-mono truncate max-w-[180px]">{fileName}</span>
                    <button
                      type="button"
                      onClick={() => setPreviewUrl(null)}
                      className="text-red-400 hover:text-red-300 font-bold flex items-center gap-1 transition"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Supprimer
                    </button>
                  </div>
                </div>
              ) : (
                <div className="p-6 border-2 border-dashed border-neutral-700/60 rounded-xl flex flex-col items-center justify-center text-center space-y-1.5 text-neutral-400">
                  <Upload className="w-7 h-7 text-neutral-500" />
                  <p className="text-xs font-bold">Aucun document chargé</p>
                  <p className="text-[10px] text-neutral-500">Choisissez une des deux options ci-dessous</p>
                </div>
              )}
            </div>

            {/* DUAL ACTION BUTTONS (As requested: Take Photo OR Load Document) */}
            <div className="space-y-2.5">
              <p className={`text-[11px] font-bold uppercase tracking-wider ${
                isLight ? 'text-slate-500' : 'text-neutral-400'
              }`}>
                Mode d’importation :
              </p>

              <div className="grid grid-cols-2 gap-3">
                {/* 1. PRENDRE UNE PHOTO */}
                <button
                  type="button"
                  onClick={startLiveCamera}
                  className={`p-4 rounded-2xl border flex flex-col items-center justify-center gap-2 transition active:scale-95 group ${
                    isLight 
                      ? 'bg-slate-100 hover:bg-yellow-50 hover:border-yellow-400 border-slate-200 text-slate-800' 
                      : 'bg-neutral-900 hover:bg-neutral-800 hover:border-yellow-400 border-neutral-800 text-white'
                  }`}
                >
                  <div className="w-12 h-12 rounded-2xl bg-yellow-400/20 text-yellow-500 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Camera className="w-6 h-6 stroke-[2.2]" />
                  </div>
                  <div className="text-center">
                    <p className="text-xs font-black">Prendre une photo</p>
                    <p className={`text-[10px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                      Appareil photo / Scan
                    </p>
                  </div>
                </button>

                {/* 2. CHARGER UN DOCUMENT */}
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className={`p-4 rounded-2xl border flex flex-col items-center justify-center gap-2 transition active:scale-95 group ${
                    isLight 
                      ? 'bg-slate-100 hover:bg-yellow-50 hover:border-yellow-400 border-slate-200 text-slate-800' 
                      : 'bg-neutral-900 hover:bg-neutral-800 hover:border-yellow-400 border-neutral-800 text-white'
                  }`}
                >
                  <div className="w-12 h-12 rounded-2xl bg-blue-500/20 text-blue-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Upload className="w-6 h-6 stroke-[2.2]" />
                  </div>
                  <div className="text-center">
                    <p className="text-xs font-black">Charger document</p>
                    <p className={`text-[10px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                      Galerie ou fichier PDF
                    </p>
                  </div>
                </button>
              </div>
            </div>

            {/* Optional Metadata Fields */}
            <div className={`p-4 rounded-2xl border space-y-3 ${
              isLight ? 'bg-white border-slate-200' : 'bg-neutral-900/40 border-neutral-800'
            }`}>
              <div>
                <label className={`block text-[11px] font-bold mb-1 ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>
                  Numéro ou référence du document
                </label>
                <input
                  type="text"
                  value={referenceNumber}
                  onChange={(e) => setReferenceNumber(e.target.value)}
                  placeholder="Ex : VTC-75-2019-0142"
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono transition focus:outline-none focus:ring-2 focus:ring-yellow-400 ${
                    isLight 
                      ? 'bg-slate-50 border-slate-300 text-slate-900' 
                      : 'bg-neutral-900 border-neutral-700 text-white'
                  }`}
                />
              </div>

              <div>
                <label className={`block text-[11px] font-bold mb-1 ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>
                  Date d’expiration
                </label>
                <input
                  type="text"
                  value={expiryDate}
                  onChange={(e) => setExpiryDate(e.target.value)}
                  placeholder="Ex : 15/09/2030"
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono transition focus:outline-none focus:ring-2 focus:ring-yellow-400 ${
                    isLight 
                      ? 'bg-slate-50 border-slate-300 text-slate-900' 
                      : 'bg-neutral-900 border-neutral-700 text-white'
                  }`}
                />
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2.5">
              <button
                type="button"
                disabled={isSubmitting}
                onClick={handleSubmit}
                className="flex-1 py-3.5 px-4 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-black font-black text-xs transition active:scale-95 flex items-center justify-center gap-2 shadow-lg shadow-yellow-400/20 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Enregistrement en cours...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4 stroke-[2.5]" />
                    <span>Valider le document</span>
                  </>
                )}
              </button>

              {documentItem.status === 'VALID' && (
                <button
                  type="button"
                  disabled={isSubmitting}
                  onClick={handleMarkMissing}
                  className="py-3.5 px-3 rounded-2xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-500 font-bold text-xs transition active:scale-95 flex items-center justify-center gap-1.5"
                  title="Marquer comme manquant pour tester le statut incomplet"
                >
                  <XCircle className="w-4 h-4" />
                  <span>Marquer manquant</span>
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
