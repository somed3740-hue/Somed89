import React, { useState } from 'react';
import { 
  X, 
  Car, 
  User, 
  Phone, 
  ShieldCheck, 
  CheckCircle2, 
  ArrowRight,
  Sparkles,
  FileText
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { RideCategory } from '../../types/vtc';
import { soundEffects } from '../../utils/audio';

interface NewDriverModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDriverCreated?: (driverId: string) => void;
}

export const NewDriverModal: React.FC<NewDriverModalProps> = ({
  isOpen,
  onClose,
  onDriverCreated,
}) => {
  const isLight = vtcStore.isLightMode();
  const passenger = vtcStore.getPassenger();

  const [name, setName] = useState(passenger.name || 'Nouveau Chauffeur SOMED');
  const [phone, setPhone] = useState(passenger.phone || '+33 6 12 34 56 78');
  const [vehicleModel, setVehicleModel] = useState('Peugeot 508 Hybrid');
  const [plate, setPlate] = useState('EK-890-TX');
  const [category, setCategory] = useState<RideCategory>('BERLINE');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleCreate = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSubmitting(true);
    soundEffects.playClick();

    setTimeout(() => {
      const newDriver = vtcStore.registerNewDriver({
        name: name.trim() || 'Nouveau Chauffeur SOMED',
        phone: phone.trim() || '+33 6 12 34 56 78',
        email: `${name.toLowerCase().replace(/\s+/g, '.')}@vtc-connect.fr`,
        vehicleModel: vehicleModel.trim() || 'Peugeot 508',
        plate: plate.trim() || 'FR-882-TK',
        category,
      });

      setIsSubmitting(false);
      onDriverCreated?.(newDriver.id);
      onClose();
    }, 500);
  };

  const handleQuickDemoCreate = () => {
    setIsSubmitting(true);
    soundEffects.playClick();

    setTimeout(() => {
      const demoNames = ['Yassine Mansouri', 'David Moreau', 'Camille Roux', 'Karim Bennani'];
      const randomName = demoNames[Math.floor(Math.random() * demoNames.length)];
      const randomPlate = `AB-${Math.floor(100 + Math.random() * 899)}-XY`;

      const newDriver = vtcStore.registerNewDriver({
        name: randomName,
        phone: '+33 6 ' + Math.floor(10000000 + Math.random() * 89999999),
        email: `${randomName.toLowerCase().replace(/\s+/g, '.')}@vtc-connect.fr`,
        vehicleModel: 'Mercedes Classe C 220d',
        plate: randomPlate,
        category: 'BERLINE',
      });

      setIsSubmitting(false);
      onDriverCreated?.(newDriver.id);
      onClose();
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-[1400] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200 select-none">
      <div 
        className={`w-full max-w-md rounded-3xl border shadow-2xl flex flex-col overflow-hidden max-h-[90vh] transition-colors ${
          isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
        }`}
      >
        {/* Header */}
        <div className={`px-5 py-4 border-b flex items-center justify-between ${
          isLight ? 'border-slate-200 bg-slate-50' : 'border-neutral-900 bg-neutral-900/60'
        }`}>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-yellow-400/20 text-yellow-500 flex items-center justify-center">
              <Car className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-sm">Inscription Nouveau Chauffeur</h2>
              <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                Dossier de conformité & habilitation VTC / Taxi
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className={`w-8 h-8 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'hover:bg-slate-200 text-slate-600' : 'hover:bg-neutral-800 text-neutral-400 hover:text-white'
            }`}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleCreate} className="p-5 overflow-y-auto space-y-4">
          {/* Information box */}
          <div className={`p-3.5 rounded-2xl border text-xs space-y-1.5 ${
            isLight ? 'bg-amber-50/80 border-amber-200 text-amber-950' : 'bg-yellow-950/20 border-yellow-500/30 text-yellow-200'
          }`}>
            <div className="flex items-center gap-2 font-bold">
              <ShieldCheck className="w-4 h-4 text-yellow-500 flex-shrink-0" />
              <span>Liste des 5 documents obligatoires par défaut</span>
            </div>
            <p className="text-[11px] opacity-90 leading-relaxed">
              Dès la création du profil, vous aurez accès à la liste complète des 5 pièces justificatives (Permis, Carte Pro, CIN, KBIS, Numéro de Taxi) prêtes à être chargées ou photographiées une par une.
            </p>
          </div>

          {/* Nom & Prénom */}
          <div>
            <label className={`block text-xs font-bold mb-1 ${isLight ? 'text-slate-700' : 'text-neutral-300'}`}>
              Nom et Prénom du chauffeur
            </label>
            <div className="relative">
              <User className={`w-4 h-4 absolute left-3.5 top-3 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex : Karim Tazi"
                className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl border text-xs font-semibold outline-none transition focus:ring-2 focus:ring-yellow-400 ${
                  isLight ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-700 text-white'
                }`}
              />
            </div>
          </div>

          {/* Téléphone */}
          <div>
            <label className={`block text-xs font-bold mb-1 ${isLight ? 'text-slate-700' : 'text-neutral-300'}`}>
              Numéro de téléphone
            </label>
            <div className="relative">
              <Phone className={`w-4 h-4 absolute left-3.5 top-3 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+33 6 12 34 56 78"
                className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl border text-xs font-semibold outline-none transition focus:ring-2 focus:ring-yellow-400 ${
                  isLight ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-700 text-white'
                }`}
              />
            </div>
          </div>

          {/* Véhicule & Immatriculation */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={`block text-xs font-bold mb-1 ${isLight ? 'text-slate-700' : 'text-neutral-300'}`}>
                Véhicule
              </label>
              <input
                type="text"
                required
                value={vehicleModel}
                onChange={(e) => setVehicleModel(e.target.value)}
                placeholder="Peugeot 508"
                className={`w-full px-3 py-2.5 rounded-xl border text-xs font-semibold outline-none transition focus:ring-2 focus:ring-yellow-400 ${
                  isLight ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-700 text-white'
                }`}
              />
            </div>

            <div>
              <label className={`block text-xs font-bold mb-1 ${isLight ? 'text-slate-700' : 'text-neutral-300'}`}>
                Immatriculation
              </label>
              <input
                type="text"
                required
                value={plate}
                onChange={(e) => setPlate(e.target.value)}
                placeholder="AB-123-CD"
                className={`w-full px-3 py-2.5 rounded-xl border text-xs font-mono font-semibold uppercase outline-none transition focus:ring-2 focus:ring-yellow-400 ${
                  isLight ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-700 text-white'
                }`}
              />
            </div>
          </div>

          {/* Catégorie */}
          <div>
            <label className={`block text-xs font-bold mb-1 ${isLight ? 'text-slate-700' : 'text-neutral-300'}`}>
              Catégorie de transport
            </label>
            <div className="grid grid-cols-4 gap-2">
              {(['BERLINE', 'CONFORT', 'STANDARD', 'VAN'] as RideCategory[]).map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className={`py-2 px-1 text-[11px] font-bold rounded-xl border transition ${
                    category === cat
                      ? 'bg-yellow-400 border-yellow-500 text-black shadow-sm'
                      : isLight 
                      ? 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100' 
                      : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:bg-neutral-800'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 space-y-2.5">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 px-4 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-xs flex items-center justify-center gap-2 transition active:scale-95 shadow-md shadow-yellow-400/20 disabled:opacity-50"
            >
              <FileText className="w-4 h-4" />
              <span>Créer le profil & Accéder aux 5 documents</span>
            </button>

            <button
              type="button"
              disabled={isSubmitting}
              onClick={handleQuickDemoCreate}
              className={`w-full py-2.5 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition active:scale-95 ${
                isLight 
                  ? 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-800' 
                  : 'bg-neutral-900 hover:bg-neutral-800 border-neutral-800 text-neutral-300'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-yellow-500" />
              <span>Créer un profil test en 1 clic (dossier vierge 0/5)</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
